using System;
using System.Collections.Generic;
using System.Linq;

namespace TriviaChallenge;

public enum GuessResult
{
    Correct,
    WrongMoreClues,
    Failed
}

public class ConnectionMode : GameMode
{
    public const int PuzzlesPerRound = 5;

    private readonly List<ConnectionPuzzle> _puzzles;
    private int _index;

    public ConnectionMode(IEnumerable<ConnectionPuzzle> pool)
    {
        _puzzles = RandomHelper.Shuffle(pool).Take(PuzzlesPerRound).ToList();
        CluesRevealed = 1;
    }

    public override string Name { get { return ModeNames.Connection; } }
    public override bool IsFinished { get { return _index >= _puzzles.Count; } }
    public override int MaxScore { get { return _puzzles.Count * ConnectionPuzzle.PointsForClues(1); } }

    public ConnectionPuzzle CurrentPuzzle { get { return IsFinished ? null : _puzzles[_index]; } }
    public int PuzzleNumber { get { return _index + 1; } }
    public int PuzzleCount { get { return _puzzles.Count; } }
    public int CluesRevealed { get; private set; }
    public int LastPoints { get; private set; }

    public int PotentialPoints { get { return ConnectionPuzzle.PointsForClues(CluesRevealed); } }

    public bool CanRevealMore
    {
        get { return CurrentPuzzle != null && CluesRevealed < CurrentPuzzle.Clues.Count; }
    }

    public bool RevealNextClue()
    {
        if (!CanRevealMore) return false;
        CluesRevealed++;
        return true;
    }

    public GuessResult SubmitGuess(string guess, double secondsTaken)
    {
        ConnectionPuzzle puzzle = CurrentPuzzle;

        if (puzzle.CheckAnswer(guess))
        {
            LastPoints = ConnectionPuzzle.PointsForClues(CluesRevealed);
            Score += LastPoints;
            Record(puzzle, true, LastPoints, secondsTaken);
            return GuessResult.Correct;
        }

        if (CanRevealMore)
        {
            CluesRevealed++;
            return GuessResult.WrongMoreClues;
        }

        LastPoints = 0;
        Record(puzzle, false, 0, secondsTaken);
        return GuessResult.Failed;
    }

    public void GiveUp(double secondsTaken)
    {
        LastPoints = 0;
        Record(CurrentPuzzle, false, 0, secondsTaken);
    }

    public void NextPuzzle()
    {
        _index++;
        CluesRevealed = 1;
        LastPoints = 0;
    }

    private void Record(ConnectionPuzzle puzzle, bool correct, int points, double seconds)
    {
        Answers.Add(new AnswerRecord
        {
            Category = puzzle.Category,
            Difficulty = "Mixed",
            Correct = correct,
            Seconds = seconds,
            Points = points
        });
    }
}
