using System;
using System.Collections.Generic;
using System.Linq;

namespace TriviaChallenge;

public class AnswerOutcome
{
    public bool Correct { get; set; }
    public bool TimedOut { get; set; }
    public int PointsAwarded { get; set; }
    public string CorrectAnswer { get; set; }
    public int NewScore { get; set; }
    public string Message { get; set; }
}

public abstract class GameMode
{
    protected readonly List<AnswerRecord> Answers = new List<AnswerRecord>();

    public abstract string Name { get; }
    public abstract bool IsFinished { get; }
    public abstract int MaxScore { get; }

    public virtual string CategoryLabel { get { return "Mixed"; } }
    public virtual string DifficultyLabel { get { return "Mixed"; } }
    public virtual string GetEndSummary() { return ""; }

    public int Score { get; protected set; }
    public int Correct { get { return Answers.Count(a => a.Correct); } }
    public int Incorrect { get { return Answers.Count(a => !a.Correct); } }
    public int AnswerCount { get { return Answers.Count; } }

    public GameResult BuildResult()
    {
        return new GameResult
        {
            PlayedAt = DateTime.Now,
            Mode = Name,
            Category = CategoryLabel,
            Difficulty = DifficultyLabel,
            Score = Score,
            MaxScore = MaxScore,
            Correct = Correct,
            Incorrect = Incorrect,
            AverageTime = Answers.Count == 0 ? 0 : Answers.Average(a => a.Seconds),
            Completed = IsFinished,
            Answers = Answers.ToList()
        };
    }
}

public abstract class QuestionGameMode : GameMode
{
    public LifelineSet Lifelines { get; } = new LifelineSet();

    public abstract Question CurrentQuestion { get; }

    public virtual bool RequiresSelection { get { return false; } }
    public virtual bool CanWalkAway { get { return false; } }
    public virtual bool CanSkip { get { return true; } }

    public virtual bool UsesTimer { get { return true; } }

    public abstract string GetHeader();
    public abstract string GetSubHeader();

    public abstract int CalculatePoints(Question question, bool correct, double secondsTaken);

    protected abstract void ApplyAnswer(Question question, bool correct, int points);

    public abstract void SkipCurrent();
    public virtual void WalkAway() { }

    protected virtual string DescribeOutcome(Question question, bool correct, bool timedOut, int points, double secondsTaken)
    {
        if (correct) return "+" + points + " POINTS";
        return timedOut ? "TIME'S UP - NO POINTS" : "NO POINTS";
    }

    public AnswerOutcome SubmitAnswer(string answer, double secondsTaken, bool timedOut)
    {
        Question question = CurrentQuestion;
        bool correct = !timedOut && question.CheckAnswer(answer);
        int points = CalculatePoints(question, correct, secondsTaken);

        Answers.Add(new AnswerRecord
        {
            Category = question.Category,
            Difficulty = question.Difficulty.ToDisplay(),
            Correct = correct,
            Seconds = secondsTaken,
            Points = points
        });

        ApplyAnswer(question, correct, points);

        return new AnswerOutcome
        {
            Correct = correct,
            TimedOut = timedOut,
            PointsAwarded = points,
            CorrectAnswer = question.FormatCorrectAnswer(),
            NewScore = Score,
            Message = DescribeOutcome(question, correct, timedOut, points, secondsTaken)
        };
    }
}
