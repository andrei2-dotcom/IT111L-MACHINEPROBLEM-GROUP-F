using System;
using System.Collections.Generic;
using System.Linq;

namespace TriviaChallenge;

public class ClassicMode : QuestionGameMode
{
    public const int QuestionsPerRound = 10;

    private readonly List<Question> _questions;
    private readonly Queue<Question> _spares;
    private readonly string _category;
    private readonly Difficulty _difficulty;
    private int _index;

    public ClassicMode(string category, Difficulty difficulty, IEnumerable<Question> pool)
    {
        _category = category;
        _difficulty = difficulty;

        List<Question> shuffled = RandomHelper.Shuffle(pool);
        _questions = shuffled.Take(QuestionsPerRound).ToList();
        _spares = new Queue<Question>(shuffled.Skip(QuestionsPerRound));
    }

    public override string Name { get { return ModeNames.Classic; } }
    public override string CategoryLabel { get { return _category ?? "All Categories"; } }
    public override string DifficultyLabel { get { return _difficulty.ToDisplay(); } }

    public override Question CurrentQuestion { get { return _index < _questions.Count ? _questions[_index] : null; } }
    public override bool IsFinished { get { return _index >= _questions.Count; } }
    public override int MaxScore { get { return _questions.Sum(q => q.MaxPoints); } }

    public override string GetHeader()
    {
        Question q = CurrentQuestion;
        return q == null ? "CLASSIC TRIVIA" : q.Category.ToUpperInvariant() + " \u2014 " + q.Points + " POINTS";
    }

    public override string GetSubHeader()
    {
        Question q = CurrentQuestion;
        if (q == null) return "";
        return "Difficulty: " + q.Difficulty.ToDisplay().ToUpperInvariant()
               + "     |     Question " + (_index + 1) + " of " + _questions.Count;
    }

    public override int CalculatePoints(Question question, bool correct, double secondsTaken)
    {
        if (!correct) return 0;
        return question.Points + question.CalculateSpeedBonus(secondsTaken);
    }

    protected override void ApplyAnswer(Question question, bool correct, int points)
    {
        Score += points;
        _index++;
    }

    protected override string DescribeOutcome(Question question, bool correct, bool timedOut, int points, double secondsTaken)
    {
        if (correct)
        {
            int bonus = question.CalculateSpeedBonus(secondsTaken);
            string text = "+" + points + " POINTS";
            if (bonus > 0) text += "   (includes +" + bonus + " speed bonus)";
            return text;
        }
        return timedOut ? "TIME'S UP - NO POINTS" : "NO POINTS";
    }

    public override void SkipCurrent()
    {
        if (IsFinished) return;
        if (_spares.Count > 0) _questions[_index] = _spares.Dequeue();
        else _questions.RemoveAt(_index);
    }
}
