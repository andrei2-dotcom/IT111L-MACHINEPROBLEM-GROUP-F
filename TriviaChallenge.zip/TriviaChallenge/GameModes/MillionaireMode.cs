using System;
using System.Collections.Generic;
using System.Linq;

namespace TriviaChallenge;

public class MillionaireMode : QuestionGameMode
{
    public static readonly int[] Prizes = { 100, 200, 300, 500, 1000, 2000, 4000, 8000, 16000, 32000 };
    public static readonly int[] CheckpointLevels = { 3, 6 };

    private static readonly Difficulty[] LevelDifficulty =
    {
        Difficulty.Easy, Difficulty.Easy, Difficulty.Easy,
        Difficulty.Medium, Difficulty.Medium, Difficulty.Medium,
        Difficulty.Hard, Difficulty.Hard, Difficulty.Hard,
        Difficulty.VeryHard
    };

    private readonly List<Question> _levelQuestions = new List<Question>();
    private readonly List<Question> _spares = new List<Question>();
    private readonly string _category;

    private int _completed;
    private bool _gameOver;
    private bool _walkedAway;

    public MillionaireMode(string category, IEnumerable<Question> pool)
    {
        _category = category;
        var available = RandomHelper.Shuffle(pool);

        for (int level = 0; level < Prizes.Length; level++)
        {
            Question pick = PickClosest(available, LevelDifficulty[level]);
            if (pick == null) break;
            available.Remove(pick);
            _levelQuestions.Add(pick);
        }

        _spares.AddRange(available);
    }

    private static Question PickClosest(List<Question> candidates, Difficulty target)
    {
        return candidates
            .OrderBy(q => Math.Abs((int)q.Difficulty - (int)target))
            .FirstOrDefault();
    }

    public override string Name { get { return ModeNames.Millionaire; } }
    public override string CategoryLabel { get { return _category ?? "All Categories"; } }

    public int LevelCount { get { return _levelQuestions.Count; } }
    public int CompletedLevels { get { return _completed; } }
    public int CurrentLevel { get { return Math.Min(_completed + 1, Math.Max(1, _levelQuestions.Count)); } }

    public bool IsCheckpoint(int level) { return CheckpointLevels.Contains(level); }

    public override bool IsFinished
    {
        get { return _gameOver || _walkedAway || _completed >= _levelQuestions.Count; }
    }

    public override int MaxScore
    {
        get { return _levelQuestions.Count == 0 ? 0 : Prizes[_levelQuestions.Count - 1]; }
    }

    public override Question CurrentQuestion { get { return IsFinished ? null : _levelQuestions[_completed]; } }
    public override bool CanWalkAway { get { return !IsFinished; } }
    public override bool CanSkip { get { return _spares.Count > 0; } }
    public override bool UsesTimer { get { return false; } }

    public override string GetHeader()
    {
        if (IsFinished) return "MILLIONAIRE MODE";
        return "LEVEL " + CurrentLevel + " \u2014 FOR " + Prizes[_completed].ToString("N0");
    }

    public override string GetSubHeader()
    {
        if (IsFinished) return "";
        Question q = CurrentQuestion;
        return "Difficulty: " + q.Difficulty.ToDisplay().ToUpperInvariant()
               + "     |     Safe prize: " + SecuredPrize().ToString("N0");
    }

    private int SecuredPrize()
    {
        int secured = 0;
        foreach (int level in CheckpointLevels)
            if (_completed >= level) secured = Prizes[level - 1];
        return secured;
    }

    public override int CalculatePoints(Question question, bool correct, double secondsTaken)
    {
        return correct ? Prizes[_completed] - Score : 0;
    }

    protected override void ApplyAnswer(Question question, bool correct, int points)
    {
        if (correct)
        {
            _completed++;
            Score = Prizes[_completed - 1];
        }
        else
        {
            Score = SecuredPrize();
            _gameOver = true;
        }
    }

    protected override string DescribeOutcome(Question question, bool correct, bool timedOut, int points, double secondsTaken)
    {
        if (correct) return "You now have " + Score.ToString("N0") + "!";
        string prefix = timedOut ? "Time ran out. " : "";
        return prefix + "You leave with " + Score.ToString("N0") + ".";
    }

    public override string GetEndSummary()
    {
        if (_walkedAway) return "You walked away with " + Score.ToString("N0") + ".";
        if (_completed >= _levelQuestions.Count && _levelQuestions.Count > 0)
            return "Congratulations! You answered every question and won " + Score.ToString("N0") + "!";
        if (_gameOver) return "Wrong answer - you fell back to your secured prize of " + Score.ToString("N0") + ".";
        return "";
    }

    public override void WalkAway()
    {
        if (!IsFinished) _walkedAway = true;
    }

    public override void SkipCurrent()
    {
        if (IsFinished || _spares.Count == 0) return;

        Question replacement = PickClosest(_spares, LevelDifficulty[_completed]);
        _spares.Remove(replacement);
        _levelQuestions[_completed] = replacement;
    }
}
