using System;
using System.Collections.Generic;
using System.Linq;

namespace TriviaChallenge;

public class JeopardyCell
{
    public string Category { get; set; }
    public int Value { get; set; }
    public Question Question { get; set; }
    public bool Played { get; set; }
    public bool IsPlayable { get { return Question != null && !Played; } }
}

public class JeopardyMode : QuestionGameMode
{
    public static readonly int[] Values = { 100, 200, 300 };

    private readonly List<string> _categories;
    private readonly JeopardyCell[,] _cells;
    private JeopardyCell _current;

    public JeopardyMode(QuestionRepository repository)
    {
        _categories = repository.Categories
            .Select(c => new { Name = c, Count = repository.Count(c, null) })
            .Where(x => x.Count > 0)
            .OrderByDescending(x => x.Count >= 3)
            .ThenBy(x => RandomHelper.Rng.Next())
            .Take(4)
            .Select(x => x.Name)
            .ToList();

        _cells = new JeopardyCell[_categories.Count, Values.Length];
        var used = new HashSet<Question>();

        for (int c = 0; c < _categories.Count; c++)
        {
            for (int r = 0; r < Values.Length; r++)
            {
                Difficulty target = (Difficulty)(r + 1);
                List<Question> candidates = repository.Find(_categories[c], null).Where(q => !used.Contains(q)).ToList();

                Question pick = RandomHelper.Shuffle(candidates.Where(q => q.Difficulty == target)).FirstOrDefault();
                if (pick == null)
                {
                    pick = RandomHelper.Shuffle(candidates)
                        .OrderBy(q => Math.Abs((int)q.Difficulty - (int)target))
                        .FirstOrDefault();
                }
                if (pick != null) used.Add(pick);

                _cells[c, r] = new JeopardyCell { Category = _categories[c], Value = Values[r], Question = pick };
            }
        }
    }

    public override string Name { get { return ModeNames.Jeopardy; } }
    public override string CategoryLabel { get { return string.Join(", ", _categories); } }

    public IReadOnlyList<string> Categories { get { return _categories; } }
    public JeopardyCell GetCell(int column, int row) { return _cells[column, row]; }

    public int PlayableCount
    {
        get
        {
            int count = 0;
            foreach (JeopardyCell cell in _cells) if (cell.IsPlayable) count++;
            return count;
        }
    }

    public bool CanStart { get { return PlayableCount > 0; } }

    public override Question CurrentQuestion { get { return _current == null ? null : _current.Question; } }
    public override bool RequiresSelection { get { return _current == null && !IsFinished; } }
    public override bool IsFinished { get { return _current == null && PlayableCount == 0; } }

    public override int MaxScore
    {
        get
        {
            int total = 0;
            foreach (JeopardyCell cell in _cells) if (cell.Question != null) total += cell.Value;
            return total;
        }
    }

    public void Select(int column, int row)
    {
        JeopardyCell cell = _cells[column, row];
        if (cell.IsPlayable) _current = cell;
    }

    public override string GetHeader()
    {
        return _current == null
            ? "JEOPARDY BOARD"
            : _current.Category.ToUpperInvariant() + " \u2014 " + _current.Value + " POINTS";
    }

    public override string GetSubHeader()
    {
        if (_current == null) return "Choose a category and a point value     |     " + PlayableCount + " questions left";
        return "Difficulty: " + _current.Question.Difficulty.ToDisplay().ToUpperInvariant();
    }

    public override int CalculatePoints(Question question, bool correct, double secondsTaken)
    {
        return correct ? _current.Value : 0;
    }

    protected override void ApplyAnswer(Question question, bool correct, int points)
    {
        Score += points;
        _current.Played = true;
        _current = null;
    }

    public override void SkipCurrent()
    {
        if (_current == null) return;
        _current.Played = true;
        _current = null;
    }
}
