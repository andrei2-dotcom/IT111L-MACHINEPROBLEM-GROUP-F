using System;
using System.Windows.Forms;

namespace TriviaChallenge;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);

        AppState.Initialize();
        Application.Run(new MainForm());
    }
}
