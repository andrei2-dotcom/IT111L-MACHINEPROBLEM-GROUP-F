using System;
using System.Drawing;
using System.Windows.Forms;

namespace TriviaChallenge;

public class ProgressStrip : Control
{
    private double _value;

    public ProgressStrip()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                 ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
        BackColor = Theme.SurfaceLight;
        FillColor = Theme.Accent;
        Height = 12;
    }

    public Color FillColor { get; set; }

    public double Value
    {
        get { return _value; }
        set
        {
            _value = Math.Max(0, Math.Min(1, value));
            Invalidate();
        }
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.Clear(BackColor);
        int width = (int)(Width * _value);
        if (width > 0)
        {
            using (var brush = new SolidBrush(FillColor))
                e.Graphics.FillRectangle(brush, 0, 0, width, Height);
        }
    }
}
