using System.Windows.Forms;

namespace TriviaChallenge;

public abstract class ScreenBase : UserControl
{
    protected ScreenBase(MainForm app)
    {
        App = app;
        Dock = DockStyle.Fill;
        BackColor = Theme.Background;
        ForeColor = Theme.TextColor;
        DoubleBuffered = true;
    }

    protected MainForm App { get; private set; }
}
