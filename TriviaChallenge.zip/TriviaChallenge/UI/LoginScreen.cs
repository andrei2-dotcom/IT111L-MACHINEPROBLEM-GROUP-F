using System;
using System.Drawing;
using System.Windows.Forms;

namespace TriviaChallenge;

public class LoginScreen : ScreenBase
{
    private readonly Panel _card;
    private readonly Label _heading;
    private readonly Label _confirmLabel;
    private readonly Label _message;
    private readonly TextBox _username;
    private readonly TextBox _password;
    private readonly TextBox _confirm;
    private readonly Button _primary;
    private readonly Button _toggle;
    private bool _registerMode;

    public LoginScreen(MainForm app) : base(app)
    {
        var stack = new Panel { Size = new Size(520, 640), BackColor = Color.Transparent };
        stack.Controls.Add(Theme.MakeCenteredLabel("TRIVIA CHALLENGE", 32f, FontStyle.Bold, Theme.Accent, 0, 70, 520));
        

        _card = Theme.MakeCard();
        _card.SetBounds(30, 130, 460, 490);
        stack.Controls.Add(_card);

        _heading = Theme.MakeLabel("LOGIN", 18f, FontStyle.Bold);
        _heading.Location = new Point(30, 20);

        Label userLabel = Theme.MakeLabel("Username", 11f, FontStyle.Regular, Theme.MutedText);
        userLabel.Location = new Point(30, 72);
        _username = Theme.MakeTextBox(false);
        _username.SetBounds(30, 100, 400, 32);

        Label passLabel = Theme.MakeLabel("Password", 11f, FontStyle.Regular, Theme.MutedText);
        passLabel.Location = new Point(30, 150);
        _password = Theme.MakeTextBox(true);
        _password.SetBounds(30, 178, 400, 32);

        _confirmLabel = Theme.MakeLabel("Confirm password", 11f, FontStyle.Regular, Theme.MutedText);
        _confirmLabel.Location = new Point(30, 228);
        _confirm = Theme.MakeTextBox(true);
        _confirm.SetBounds(30, 256, 400, 32);

        _message = Theme.MakeLabel("", 10.5f, FontStyle.Regular, Theme.BadText);
        _message.AutoSize = false;
        _message.Size = new Size(400, 44);

        _primary = Theme.MakeButton("LOGIN", Theme.Primary, Theme.FontButton, 50);
        _primary.Width = 400;
        _primary.Left = 30;

        _toggle = Theme.MakeButton("CREATE ACCOUNT", Theme.SurfaceLight, Theme.FontSmallBold, 44);
        _toggle.Width = 400;
        _toggle.Left = 30;

        _message.Left = 30;

        _card.Controls.Add(_heading);
        _card.Controls.Add(userLabel);
        _card.Controls.Add(_username);
        _card.Controls.Add(passLabel);
        _card.Controls.Add(_password);
        _card.Controls.Add(_confirmLabel);
        _card.Controls.Add(_confirm);
        _card.Controls.Add(_message);
        _card.Controls.Add(_primary);
        _card.Controls.Add(_toggle);

        _primary.Click += (sender, e) => Submit();
        _toggle.Click += (sender, e) =>
        {
            _registerMode = !_registerMode;
            ApplyMode();
        };

        foreach (TextBox box in new[] { _username, _password, _confirm })
        {
            box.KeyDown += (sender, e) =>
            {
                if (e.KeyCode == Keys.Enter)
                {
                    e.SuppressKeyPress = true;
                    Submit();
                }
            };
        }

        ApplyMode();
        Controls.Add(stack);
        Theme.Center(stack, this);
    }

    private void ApplyMode()
    {
        int shift = _registerMode ? 0 : -84;

        _heading.Text = _registerMode ? "CREATE ACCOUNT" : "LOGIN";
        _confirmLabel.Visible = _registerMode;
        _confirm.Visible = _registerMode;

        _message.Top = 318 + shift;
        _primary.Top = 372 + shift;
        _toggle.Top = 432 + shift;
        _card.Height = 490 + shift;

        _primary.Text = _registerMode ? "REGISTER" : "LOGIN";
        _toggle.Text = _registerMode ? "BACK TO LOGIN" : "CREATE ACCOUNT";
        _message.Text = "";
    }

    private void ShowMessage(string text, bool good)
    {
        _message.ForeColor = good ? Theme.GoodText : Theme.BadText;
        _message.Text = text;
    }

    private void Submit()
    {
        if (_registerMode)
        {
            var result = AppState.Accounts.Register(_username.Text, _password.Text, _confirm.Text);
            if (!result.Success)
            {
                ShowMessage(result.Message, false);
                return;
            }

            string name = _username.Text.Trim();
            _registerMode = false;
            ApplyMode();
            _username.Text = name;
            _password.Clear();
            _confirm.Clear();
            ShowMessage(result.Message, true);
        }
        else
        {
            var result = AppState.Accounts.Login(_username.Text, _password.Text);
            if (!result.Success)
            {
                ShowMessage(result.Message, false);
                return;
            }
            App.Navigate(new MainMenuScreen(App));
        }
    }
}
