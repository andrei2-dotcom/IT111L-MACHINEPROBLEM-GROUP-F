using System;
using System.Drawing;
using System.Windows.Forms;

namespace TriviaChallenge;

public class ProfileScreen : ScreenBase
{
    public ProfileScreen(MainForm app) : base(app)
    {
        Player player = AppState.Accounts.CurrentPlayer;

        const int width = 700;
        var stack = new Panel { Width = width, BackColor = Color.Transparent };
        int y = 0;

        AddLine(stack, "PROFILE", 30f, FontStyle.Bold, Theme.Accent, 56, ref y);
        AddLine(stack, player.Username, 22f, FontStyle.Bold, Theme.TextColor, 40, ref y);

        int level = player.Level;
        int xp = player.Xp;
        int next = ProgressionSystem.XpForNextLevel(level);
        AddLine(stack, "Level " + level + " \u2014 " + player.Title, 16f, FontStyle.Regular, Theme.MutedText, 32, ref y);

        var bar = new ProgressStrip { Left = 100, Top = y + 4, Width = 500, Height = 14 };
        if (next < 0) bar.Value = 1;
        else
        {
            int floor = ProgressionSystem.XpForCurrentLevel(level);
            bar.Value = (double)(xp - floor) / (next - floor);
        }
        stack.Controls.Add(bar);
        y += 26;

        string xpText = next < 0
            ? xp + " XP \u2014 maximum level reached"
            : xp + " XP \u2014 " + (next - xp) + " XP to Level " + (level + 1);
        AddLine(stack, xpText, 11f, FontStyle.Regular, Theme.MutedText, 26, ref y);
        y += 16;

        AddLine(stack, "HIGH SCORES", 14f, FontStyle.Bold, Theme.Accent, 32, ref y);
        AddLine(stack, "Overall highest score: " + player.HighScore.ToString("N0"), 13f, FontStyle.Bold, Theme.TextColor, 28, ref y);
        foreach (string mode in ModeNames.All)
            AddLine(stack, mode + ":  " + player.GetHighScore(mode).ToString("N0"), 12f, FontStyle.Regular, Theme.TextColor, 26, ref y);
        y += 16;

        AddLine(stack, "UNLOCKS", 14f, FontStyle.Bold, Theme.Accent, 32, ref y);
        foreach (string mode in ModeNames.All)
        {
            bool open = ProgressionSystem.IsUnlocked(player, mode);
            AddLine(stack, mode + ":  " + (open ? "unlocked" : "unlocks at Level " + ProgressionSystem.RequiredLevel(mode)),
                    12f, FontStyle.Regular, open ? Theme.GoodText : Theme.MutedText, 26, ref y);
        }
        bool hardOpen = ProgressionSystem.IsUnlocked(player, Difficulty.Hard);
        AddLine(stack, "Hard difficulty:  " + (hardOpen ? "unlocked" : "unlocks at Level " + ProgressionSystem.RequiredLevel(Difficulty.Hard)),
                12f, FontStyle.Regular, hardOpen ? Theme.GoodText : Theme.MutedText, 26, ref y);

        y += 24;
        Button back = Theme.MakeButton("BACK", Theme.SurfaceLight, Theme.FontButton, 50);
        back.SetBounds((width - 200) / 2, y, 200, 50);
        back.Click += (sender, e) => App.Navigate(new MainMenuScreen(App));
        stack.Controls.Add(back);
        y += 50;

        stack.Height = y;
        Controls.Add(stack);
        Theme.Center(stack, this);
    }

    private static void AddLine(Panel panel, string text, float size, FontStyle style, Color color, int height, ref int y)
    {
        panel.Controls.Add(Theme.MakeCenteredLabel(text, size, style, color, y, height, panel.Width));
        y += height;
    }
}
