using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace TriviaChallenge;

public class MainMenuScreen : ScreenBase
{
    private readonly Player _player;
    private readonly ToolTip _tips = new ToolTip();
    private readonly Label _lblQuestions;
    private readonly Label _lblNotice;

    public MainMenuScreen(MainForm app) : base(app)
    {
        _player = AppState.Accounts.CurrentPlayer;

        var stack = new Panel { Size = new Size(680, 640), BackColor = Color.Transparent };

        stack.Controls.Add(Theme.MakeCenteredLabel("TRIVIA CHALLENGE", 32f, FontStyle.Bold, Theme.Accent, 0, 60, 680));
        stack.Controls.Add(Theme.MakeCenteredLabel("Welcome, " + _player.Username + "!", 16f, FontStyle.Bold, Theme.TextColor, 60, 34, 680));

        int level = _player.Level;
        int xp = _player.Xp;
        int nextXp = ProgressionSystem.XpForNextLevel(level);
        string xpText = nextXp < 0 ? xp + " XP (max level)" : xp + " / " + nextXp + " XP";
        stack.Controls.Add(Theme.MakeCenteredLabel(
            "Level " + level + " \u2014 " + _player.Title + "     |     " + xpText,
            11f, FontStyle.Regular, Theme.MutedText, 98, 26, 680));

        var bar = new ProgressStrip { Left = 90, Top = 130, Width = 500, Height = 12 };
        if (nextXp < 0) bar.Value = 1;
        else
        {
            int floor = ProgressionSystem.XpForCurrentLevel(level);
            bar.Value = (double)(xp - floor) / (nextXp - floor);
        }
        stack.Controls.Add(bar);

        var grid = new TableLayoutPanel
        {
            Left = 0,
            Top = 165,
            Size = new Size(680, 336),
            ColumnCount = 2,
            RowCount = 4,
            BackColor = Color.Transparent
        };
        grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
        grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
        for (int i = 0; i < 4; i++) grid.RowStyles.Add(new RowStyle(SizeType.Percent, 25f));

        grid.Controls.Add(MakeModeButton(ModeNames.Classic, "Pick a category and difficulty and answer 10 questions."), 0, 0);
        grid.Controls.Add(MakeModeButton(ModeNames.Jeopardy, "Choose from a board of categories and point values."), 1, 0);
        grid.Controls.Add(MakeModeButton(ModeNames.Connection, "Find what the clues have in common - fewer clues = more points."), 0, 1);
        grid.Controls.Add(MakeModeButton(ModeNames.Millionaire, "Climb 10 prize levels. Safe levels at 3 and 6."), 1, 1);

        Button performance = MakeMenuButton("PERFORMANCE", Theme.SurfaceLight);
        performance.Click += (sender, e) => App.Navigate(new PerformanceScreen(App));
        Button profile = MakeMenuButton("PROFILE", Theme.SurfaceLight);
        profile.Click += (sender, e) => App.Navigate(new ProfileScreen(App));
        Button logout = MakeMenuButton("LOGOUT", Theme.Bad);
        logout.Click += (sender, e) =>
        {
            AppState.Accounts.Logout();
            App.Navigate(new LoginScreen(App));
        };

        grid.Controls.Add(performance, 0, 2);
        grid.Controls.Add(profile, 1, 2);
        grid.Controls.Add(logout, 0, 3);
        grid.SetColumnSpan(logout, 2);
        stack.Controls.Add(grid);

        _lblQuestions = Theme.MakeLabel("", 10f, FontStyle.Regular, Theme.MutedText);
        _lblQuestions.AutoSize = false;
        _lblQuestions.SetBounds(0, 515, 520, 28);
        _lblQuestions.TextAlign = ContentAlignment.MiddleLeft;
        stack.Controls.Add(_lblQuestions);

        Button reload = Theme.MakeButton("Reload Questions", Theme.SurfaceLight, Theme.FontSmallBold, 32);
        reload.SetBounds(530, 513, 150, 32);
        reload.Click += (sender, e) => ReloadQuestions();
        stack.Controls.Add(reload);

        _lblNotice = Theme.MakeLabel("", 10f, FontStyle.Regular, Theme.Accent);
        _lblNotice.AutoSize = false;
        _lblNotice.SetBounds(0, 550, 680, 60);
        stack.Controls.Add(_lblNotice);

        RefreshQuestionInfo();

        Controls.Add(stack);
        Theme.Center(stack, this);
    }

    private Button MakeMenuButton(string text, Color color)
    {
        Button button = Theme.MakeButton(text, color, Theme.FontButton, 60);
        button.Dock = DockStyle.Fill;
        button.Margin = new Padding(6);
        return button;
    }

    private Button MakeModeButton(string mode, string description)
    {
        bool unlocked = ProgressionSystem.IsUnlocked(_player, mode);
        string text = mode.ToUpperInvariant();
        if (!unlocked) text += "\n(locked - reach Level " + ProgressionSystem.RequiredLevel(mode) + ")";

        Button button = MakeMenuButton(text, unlocked ? Theme.Primary : Theme.Disabled);
        button.Click += (sender, e) => GameLauncher.Start(App, mode);
        _tips.SetToolTip(button, description);
        return button;
    }

    private void RefreshQuestionInfo()
    {
        QuestionRepository repo = AppState.Questions;
        _lblQuestions.Text = "Questions loaded: " + repo.QuestionCount + "     |     Connection puzzles: " + repo.PuzzleCount;

        if (repo.QuestionCount == 0 && repo.PuzzleCount == 0)
        {
            _lblNotice.Text = "The question bank is empty. Fill in Data\\questions.json (see README.md), " +
                              "then press \"Reload Questions\".\nFile: " + AppState.QuestionFilePath;
        }
        else
        {
            _lblNotice.Text = "";
        }
    }

    private void ReloadQuestions()
    {
        AppState.Questions.Load(AppState.QuestionFilePath);
        RefreshQuestionInfo();

        if (AppState.Questions.Warnings.Count > 0)
        {
            MessageBox.Show(string.Join("\n", AppState.Questions.Warnings.Take(10)),
                            "Problems in questions.json", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) _tips.Dispose();
        base.Dispose(disposing);
    }
}
