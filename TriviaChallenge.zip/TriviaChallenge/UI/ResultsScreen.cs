using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace TriviaChallenge;

public class ResultsScreen : ScreenBase
{
    public ResultsScreen(MainForm app, GameMode mode, GameResult result, int oldLevel, Action replay) : base(app)
    {
        const int width = 640;
        var stack = new Panel { Width = width, BackColor = Color.Transparent };
        int y = 0;

        AddLine(stack, "GAME OVER", 36f, FontStyle.Bold, Theme.Accent, 60, ref y);
        AddLine(stack, result.Mode + "   |   " + result.Category + "   |   " + result.Difficulty,
                11f, FontStyle.Regular, Theme.MutedText, 30, ref y);
        y += 8;
        AddLine(stack, "FINAL SCORE: " + result.Score.ToString("N0"), 30f, FontStyle.Bold, Theme.TextColor, 56, ref y);
        AddLine(stack, "Maximum possible: " + result.MaxScore.ToString("N0"), 10.5f, FontStyle.Regular, Theme.MutedText, 24, ref y);
        y += 10;

        AddLine(stack, "Correct: " + result.Correct, 16f, FontStyle.Regular, Theme.GoodText, 32, ref y);
        AddLine(stack, "Incorrect: " + result.Incorrect, 16f, FontStyle.Regular, Theme.BadText, 32, ref y);
        AddLine(stack, "Accuracy: " + result.Accuracy.ToString("0") + "%", 16f, FontStyle.Regular, Theme.TextColor, 32, ref y);
        AddLine(stack, "Average Time: " + result.AverageTime.ToString("0.0") + " seconds", 16f, FontStyle.Regular, Theme.TextColor, 32, ref y);
        y += 8;

        if (mode.AnswerCount == 0)
        {
            AddLine(stack, "No questions were answered, so this game was not saved.", 11f, FontStyle.Italic, Theme.MutedText, 30, ref y);
        }
        else
        {
            if (result.NewHighScore)
                AddLine(stack, "NEW HIGH SCORE!", 24f, FontStyle.Bold, Theme.Accent, 48, ref y);

            string summary = mode.GetEndSummary();
            if (summary.Length > 0)
                AddLine(stack, summary, 13f, FontStyle.Regular, Theme.TextColor, 34, ref y);

            Player player = AppState.Accounts.CurrentPlayer;
            AddLine(stack, "+" + result.XpEarned + " XP earned     (total " + player.Xp + " XP)",
                    11.5f, FontStyle.Regular, Theme.MutedText, 28, ref y);

            if (player.Level > oldLevel)
            {
                AddLine(stack, "LEVEL UP!  You are now Level " + player.Level + " \u2014 " + player.Title,
                        15f, FontStyle.Bold, Theme.GoodText, 34, ref y);

                for (int level = oldLevel + 1; level <= player.Level; level++)
                {
                    List<string> unlocks = ProgressionSystem.UnlocksAtLevel(level);
                    foreach (string unlock in unlocks)
                        AddLine(stack, unlock, 11.5f, FontStyle.Regular, Theme.Accent, 24, ref y);
                }
            }
        }

        y += 24;
        Button again = Theme.MakeButton("PLAY AGAIN", Theme.Good, Theme.FontButton, 54);
        again.SetBounds(0, y, 200, 54);
        again.Click += (sender, e) => replay();

        Button performance = Theme.MakeButton("PERFORMANCE", Theme.Primary, Theme.FontButton, 54);
        performance.SetBounds(220, y, 200, 54);
        performance.Click += (sender, e) => App.Navigate(new PerformanceScreen(App));

        Button menu = Theme.MakeButton("MAIN MENU", Theme.SurfaceLight, Theme.FontButton, 54);
        menu.SetBounds(440, y, 200, 54);
        menu.Click += (sender, e) => App.Navigate(new MainMenuScreen(App));

        stack.Controls.Add(again);
        stack.Controls.Add(performance);
        stack.Controls.Add(menu);
        y += 54;

        stack.Height = y;
        Controls.Add(stack);
        Theme.Center(stack, this);
    }

    private static void AddLine(Panel panel, string text, float size, FontStyle style, Color color, int height, ref int y)
    {
        panel.Controls.Add(Theme.MakeCenteredLabel(text, size, style, color, y, height, panel.Width));
        y += height;
    }
}
