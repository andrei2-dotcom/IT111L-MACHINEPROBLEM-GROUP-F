using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace TriviaChallenge;

public static class GameLauncher
{
    public static void Start(MainForm app, string mode)
    {
        Player player = AppState.Accounts.CurrentPlayer;
        if (!ProgressionSystem.IsUnlocked(player, mode))
        {
            MessageBox.Show(mode + " unlocks at Level " + ProgressionSystem.RequiredLevel(mode) +
                            ".\nEarn XP by answering questions correctly in the other modes!",
                            "Locked", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        switch (mode)
        {
            case ModeNames.Classic: app.Navigate(new ClassicSetupScreen(app)); break;
            case ModeNames.Jeopardy: StartJeopardy(app); break;
            case ModeNames.Connection: StartConnection(app); break;
            case ModeNames.Millionaire: StartMillionaire(app); break;
        }
    }

    public static void StartClassic(MainForm app, string category, Difficulty difficulty)
    {
        List<Question> pool = AppState.Questions.Find(category, difficulty).ToList();
        if (pool.Count == 0)
        {
            ShowNoQuestions("There are no " + difficulty.ToDisplay() + " questions" +
                            (category == null ? "" : " in " + category) + " yet.");
            return;
        }

        var mode = new ClassicMode(category, difficulty, pool);
        app.Navigate(new GameScreen(app, mode, () => StartClassic(app, category, difficulty)));
    }

    public static void StartJeopardy(MainForm app)
    {
        var mode = new JeopardyMode(AppState.Questions);
        if (!mode.CanStart)
        {
            ShowNoQuestions("The Jeopardy board needs questions in at least one category.");
            return;
        }
        app.Navigate(new GameScreen(app, mode, () => StartJeopardy(app)));
    }

    public static void StartMillionaire(MainForm app)
    {
        var mode = new MillionaireMode(null, AppState.Questions.Questions);
        if (mode.LevelCount == 0)
        {
            ShowNoQuestions("Millionaire mode needs questions (ideally 10, from Easy to Hard).");
            return;
        }
        app.Navigate(new GameScreen(app, mode, () => StartMillionaire(app)));
    }

    public static void StartConnection(MainForm app)
    {
        var mode = new ConnectionMode(AppState.Questions.Puzzles);
        if (mode.PuzzleCount == 0)
        {
            ShowNoQuestions("There are no Connection puzzles yet (add them under \"connections\").");
            return;
        }
        app.Navigate(new ConnectionScreen(app, mode, () => StartConnection(app)));
    }

    public static void Finish(MainForm app, GameMode mode, Action replay)
    {
        Player player = AppState.Accounts.CurrentPlayer;
        int oldLevel = player.Level;
        GameResult result = mode.BuildResult();

        if (mode.AnswerCount > 0) AppState.Tracker.RecordGame(player, result);
        app.Navigate(new ResultsScreen(app, mode, result, oldLevel, replay));
    }

    public static void QuitToMenu(MainForm app, GameMode mode)
    {
        if (mode.AnswerCount > 0)
            AppState.Tracker.RecordGame(AppState.Accounts.CurrentPlayer, mode.BuildResult());
        app.Navigate(new MainMenuScreen(app));
    }

    private static void ShowNoQuestions(string reason)
    {
        MessageBox.Show(reason + "\n\nAdd questions to Data\\questions.json (see README.md), then press " +
                        "\"Reload Questions\" on the main menu.",
                        "No questions available", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
}
