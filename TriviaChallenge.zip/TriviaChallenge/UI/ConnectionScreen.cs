using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace TriviaChallenge;

public class ConnectionScreen : ScreenBase
{
    private readonly ConnectionMode _mode;
    private readonly Action _replay;
    private readonly Stopwatch _stopwatch = new Stopwatch();

    private readonly GameTopBar _top;
    private readonly Label[] _clueLabels = new Label[4];
    private readonly Label _lblPoints;
    private readonly Label _lblResult;
    private readonly TextBox _txtGuess;
    private readonly Button _btnSubmit;
    private readonly Button _btnReveal;
    private readonly Button _btnGiveUp;
    private readonly Button _btnNext;
    private bool _puzzleOver;

    public ConnectionScreen(MainForm app, ConnectionMode mode, Action replay) : base(app)
    {
        _mode = mode;
        _replay = replay;

        _top = new GameTopBar { Dock = DockStyle.Top, Height = 84, Padding = new Padding(24, 12, 24, 0) };
        _top.Quit.Click += (sender, e) => OnQuit();

        var body = new Panel { Size = new Size(800, 540), BackColor = Color.Transparent };

        body.Controls.Add(Theme.MakeCenteredLabel("What do these clues have in common?", 16f, FontStyle.Bold, Theme.TextColor, 0, 36, 800));

        var clueTable = new TableLayoutPanel
        {
            Left = 0,
            Top = 46,
            Size = new Size(800, 190),
            ColumnCount = 2,
            RowCount = 2,
            BackColor = Color.Transparent
        };
        clueTable.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
        clueTable.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
        clueTable.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
        clueTable.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
        for (int i = 0; i < _clueLabels.Length; i++)
        {
            Label clue = Theme.MakeFillLabel("?", 20f, FontStyle.Bold, Theme.MutedText, ContentAlignment.MiddleCenter);
            clue.BackColor = Theme.Surface;
            clue.Margin = new Padding(6);
            _clueLabels[i] = clue;
            clueTable.Controls.Add(clue, i % 2, i / 2);
        }
        body.Controls.Add(clueTable);

        _lblPoints = Theme.MakeCenteredLabel("", 13f, FontStyle.Bold, Theme.Accent, 244, 30, 800);
        body.Controls.Add(_lblPoints);

        _txtGuess = Theme.MakeTextBox(false);
        _txtGuess.Font = new Font("Segoe UI", 18f);
        _txtGuess.SetBounds(0, 282, 800, 40);
        _txtGuess.KeyDown += (sender, e) =>
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                OnSubmit();
            }
        };
        body.Controls.Add(_txtGuess);

        _btnSubmit = Theme.MakeButton("SUBMIT GUESS", Theme.Primary, Theme.FontButton, 50);
        _btnSubmit.SetBounds(0, 336, 300, 50);
        _btnSubmit.Click += (sender, e) => OnSubmit();

        _btnReveal = Theme.MakeButton("REVEAL NEXT CLUE", Theme.SurfaceLight, Theme.FontSmallBold, 50);
        _btnReveal.SetBounds(310, 336, 240, 50);
        _btnReveal.Click += (sender, e) =>
        {
            _mode.RevealNextClue();
            RefreshClues(false);
            _txtGuess.Focus();
        };

        _btnGiveUp = Theme.MakeButton("GIVE UP", Theme.Bad, Theme.FontSmallBold, 50);
        _btnGiveUp.SetBounds(560, 336, 240, 50);
        _btnGiveUp.Click += (sender, e) => OnGiveUp();

        body.Controls.Add(_btnSubmit);
        body.Controls.Add(_btnReveal);
        body.Controls.Add(_btnGiveUp);

        _lblResult = Theme.MakeCenteredLabel("", 15f, FontStyle.Bold, Theme.TextColor, 396, 80, 800);
        body.Controls.Add(_lblResult);

        _btnNext = Theme.MakeButton("NEXT PUZZLE", Theme.Good, Theme.FontButton, 54);
        _btnNext.SetBounds(250, 484, 300, 54);
        _btnNext.Visible = false;
        _btnNext.Click += (sender, e) => OnNext();
        body.Controls.Add(_btnNext);

        Controls.Add(body);
        Controls.Add(_top);
        Theme.Center(body, this, 84);
    }

    protected override void OnLoad(EventArgs e)
    {
        base.OnLoad(e);
        LoadPuzzle();
    }

    private void LoadPuzzle()
    {
        _puzzleOver = false;
        _top.Header.Text = "CONNECTION MODE";
        _top.Sub.Text = "Puzzle " + _mode.PuzzleNumber + " of " + _mode.PuzzleCount + "     |     Fewer clues = more points";
        _top.Score.Text = "Score: " + _mode.Score.ToString("N0");

        _lblResult.Text = "";
        _btnNext.Visible = false;
        _txtGuess.Text = "";
        _txtGuess.Enabled = true;
        Theme.SetButtonEnabled(_btnSubmit, true, Theme.Primary);
        Theme.SetButtonEnabled(_btnGiveUp, true, Theme.Bad);

        RefreshClues(false);
        _stopwatch.Restart();
        _txtGuess.Focus();
    }

    private void RefreshClues(bool revealAll)
    {
        ConnectionPuzzle puzzle = _mode.CurrentPuzzle;
        for (int i = 0; i < _clueLabels.Length; i++)
        {
            bool exists = i < puzzle.Clues.Count;
            bool revealed = exists && (revealAll || i < _mode.CluesRevealed);

            _clueLabels[i].Visible = exists;
            _clueLabels[i].Text = revealed ? puzzle.Clues[i] : "?";
            _clueLabels[i].ForeColor = revealed ? Theme.TextColor : Theme.MutedText;
        }

        _lblPoints.Text = _puzzleOver ? "" : "Points if solved now: " + _mode.PotentialPoints;
        Theme.SetButtonEnabled(_btnReveal, !_puzzleOver && _mode.CanRevealMore, Theme.SurfaceLight);
    }

    private void OnSubmit()
    {
        if (_puzzleOver) return;
        string guess = _txtGuess.Text.Trim();
        if (guess.Length == 0) return;

        ConnectionPuzzle puzzle = _mode.CurrentPuzzle;
        GuessResult result = _mode.SubmitGuess(guess, _stopwatch.Elapsed.TotalSeconds);

        switch (result)
        {
            case GuessResult.Correct:
                EndPuzzle(true, "CORRECT!  They are all connected by: " + puzzle.Answer + "\n+" + _mode.LastPoints + " POINTS");
                break;

            case GuessResult.WrongMoreClues:
                _lblResult.ForeColor = Theme.BadText;
                _lblResult.Text = "Not quite - another clue has been revealed.";
                _txtGuess.Clear();
                RefreshClues(false);
                _txtGuess.Focus();
                break;

            default:
                EndPuzzle(false, "Out of clues! The connection was: " + puzzle.Answer);
                break;
        }
    }

    private void OnGiveUp()
    {
        if (_puzzleOver) return;
        ConnectionPuzzle puzzle = _mode.CurrentPuzzle;
        _mode.GiveUp(_stopwatch.Elapsed.TotalSeconds);
        EndPuzzle(false, "The connection was: " + puzzle.Answer);
    }

    private void EndPuzzle(bool solved, string message)
    {
        _puzzleOver = true;
        _stopwatch.Stop();

        _lblResult.ForeColor = solved ? Theme.GoodText : Theme.BadText;
        _lblResult.Text = message;
        _top.Score.Text = "Score: " + _mode.Score.ToString("N0");

        _txtGuess.Enabled = false;
        Theme.SetButtonEnabled(_btnSubmit, false, Theme.Primary);
        Theme.SetButtonEnabled(_btnGiveUp, false, Theme.Bad);
        RefreshClues(true);

        bool last = _mode.PuzzleNumber >= _mode.PuzzleCount;
        _btnNext.Text = last ? "SEE RESULTS" : "NEXT PUZZLE";
        _btnNext.Visible = true;
    }

    private void OnNext()
    {
        _mode.NextPuzzle();
        if (_mode.IsFinished)
            GameLauncher.Finish(App, _mode, _replay);
        else
            LoadPuzzle();
    }

    private void OnQuit()
    {
        _stopwatch.Stop();
        string text = _mode.AnswerCount > 0
            ? "Quit this game? Your progress so far will be saved."
            : "Quit this game?";

        if (MessageBox.Show(text, "Quit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
        {
            if (!_puzzleOver) _stopwatch.Start();
            return;
        }
        GameLauncher.QuitToMenu(App, _mode);
    }
}
