using System;
using System.Drawing;
using System.Windows.Forms;

namespace TriviaChallenge;

public static class Theme
{
    public static readonly Color Background = Color.FromArgb(20, 24, 44);
    public static readonly Color Surface = Color.FromArgb(34, 40, 68);
    public static readonly Color SurfaceLight = Color.FromArgb(50, 58, 96);
    public static readonly Color Primary = Color.FromArgb(79, 70, 229);
    public static readonly Color Accent = Color.FromArgb(250, 190, 40);
    public static readonly Color TextColor = Color.White;
    public static readonly Color MutedText = Color.FromArgb(160, 170, 200);
    public static readonly Color Good = Color.FromArgb(34, 150, 90);
    public static readonly Color GoodText = Color.FromArgb(90, 225, 140);
    public static readonly Color Bad = Color.FromArgb(205, 60, 60);
    public static readonly Color BadText = Color.FromArgb(255, 110, 110);
    public static readonly Color Disabled = Color.FromArgb(62, 68, 98);

    public static readonly Font FontBody = new Font("Segoe UI", 13f);
    public static readonly Font FontQuestion = new Font("Segoe UI", 20f, FontStyle.Bold);
    public static readonly Font FontButton = new Font("Segoe UI", 13f, FontStyle.Bold);
    public static readonly Font FontSmall = new Font("Segoe UI", 10f);
    public static readonly Font FontSmallBold = new Font("Segoe UI", 10f, FontStyle.Bold);
    public static readonly Font FontBoard = new Font("Segoe UI", 26f, FontStyle.Bold);

    public static Button MakeButton(string text, Color? back = null, Font font = null, int height = 48)
    {
        Color color = back ?? Primary;
        var button = new Button
        {
            Text = text,
            FlatStyle = FlatStyle.Flat,
            BackColor = color,
            ForeColor = Color.White,
            Font = font ?? FontButton,
            Cursor = Cursors.Hand,
            UseVisualStyleBackColor = false,
            UseMnemonic = false,
            Height = height
        };
        button.FlatAppearance.BorderSize = 0;
        button.FlatAppearance.MouseOverBackColor = ControlPaint.Light(color, 0.15f);
        return button;
    }

    public static void SetButtonEnabled(Button button, bool enabled, Color enabledColor)
    {
        button.Enabled = enabled;
        button.BackColor = enabled ? enabledColor : Disabled;
        button.FlatAppearance.MouseOverBackColor = enabled ? ControlPaint.Light(enabledColor, 0.15f) : Disabled;
        button.Cursor = enabled ? Cursors.Hand : Cursors.Default;
    }

    public static Label MakeLabel(string text, float size = 12f, FontStyle style = FontStyle.Regular, Color? color = null)
    {
        return new Label
        {
            Text = text,
            AutoSize = true,
            BackColor = Color.Transparent,
            ForeColor = color ?? TextColor,
            Font = new Font("Segoe UI", size, style),
            UseMnemonic = false
        };
    }

    public static Label MakeFillLabel(string text, float size, FontStyle style, Color color, ContentAlignment align)
    {
        Label label = MakeLabel(text, size, style, color);
        label.AutoSize = false;
        label.Dock = DockStyle.Fill;
        label.TextAlign = align;
        return label;
    }

    public static Label MakeCenteredLabel(string text, float size, FontStyle style, Color color, int top, int height, int width)
    {
        Label label = MakeLabel(text, size, style, color);
        label.AutoSize = false;
        label.SetBounds(0, top, width, height);
        label.TextAlign = ContentAlignment.MiddleCenter;
        return label;
    }

    public static TextBox MakeTextBox(bool password)
    {
        return new TextBox
        {
            Font = new Font("Segoe UI", 14f),
            BackColor = SurfaceLight,
            ForeColor = Color.White,
            BorderStyle = BorderStyle.FixedSingle,
            UseSystemPasswordChar = password
        };
    }

    public static Panel MakeCard()
    {
        return new Panel { BackColor = Surface };
    }

    public static void Center(Control child, Control parent, int topReserved = 0)
    {
        EventHandler place = (sender, e) =>
        {
            child.Left = Math.Max(0, (parent.ClientSize.Width - child.Width) / 2);
            child.Top = topReserved + Math.Max(0, (parent.ClientSize.Height - topReserved - child.Height) / 2);
        };
        parent.Resize += place;
        place(parent, EventArgs.Empty);
    }
}
