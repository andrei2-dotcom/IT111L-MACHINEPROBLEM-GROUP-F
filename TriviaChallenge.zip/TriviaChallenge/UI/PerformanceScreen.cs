using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace TriviaChallenge;

public class PerformanceScreen : ScreenBase
{
    public PerformanceScreen(MainForm app) : base(app)
    {
        Player player = AppState.Accounts.CurrentPlayer;
        PerformanceSummary s = AppState.Tracker.Summarize(player);

        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 5,
            Padding = new Padding(30, 16, 30, 16),
            BackColor = Color.Transparent
        };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 60f));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 190f));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 40f));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 70f));

        root.Controls.Add(Theme.MakeFillLabel("PERFORMANCE \u2014 " + player.Username, 24f, FontStyle.Bold, Theme.Accent, ContentAlignment.MiddleLeft), 0, 0);

        var tiles = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 5,
            RowCount = 2,
            BackColor = Color.Transparent
        };
        for (int i = 0; i < 5; i++) tiles.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20f));
        tiles.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
        tiles.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));

        string fastest = s.FastestAnswer.HasValue ? s.FastestAnswer.Value.ToString("0.0") + " s" : "N/A";
        AddTile(tiles, 0, "Highest Score", s.HighScore.ToString("N0"));
        AddTile(tiles, 1, "Games Played", s.GamesPlayed.ToString());
        AddTile(tiles, 2, "Questions Answered", s.QuestionsAnswered.ToString());
        AddTile(tiles, 3, "Correct", s.Correct.ToString());
        AddTile(tiles, 4, "Incorrect", s.Incorrect.ToString());
        AddTile(tiles, 5, "Accuracy", s.Accuracy.ToString("0") + "%");
        AddTile(tiles, 6, "Fastest Answer", fastest);
        AddTile(tiles, 7, "Best Category", s.BestCategory);
        AddTile(tiles, 8, "Best Game Mode", s.BestMode);
        AddTile(tiles, 9, "Highest Difficulty Cleared", s.HighestDifficulty);
        root.Controls.Add(tiles, 0, 1);

        root.Controls.Add(Theme.MakeFillLabel("Game History (newest first)", 13f, FontStyle.Bold, Theme.TextColor, ContentAlignment.BottomLeft), 0, 2);

        var list = new ListView
        {
            Dock = DockStyle.Fill,
            View = View.Details,
            FullRowSelect = true,
            GridLines = true,
            BorderStyle = BorderStyle.None,
            BackColor = Theme.Surface,
            ForeColor = Color.White,
            Font = Theme.FontSmall,
            HideSelection = false
        };
        list.Columns.Add("Date", 140);
        list.Columns.Add("Mode", 120);
        list.Columns.Add("Category", 150);
        list.Columns.Add("Difficulty", 80);
        list.Columns.Add("Score", 110);
        list.Columns.Add("Correct", 65);
        list.Columns.Add("Incorrect", 70);
        list.Columns.Add("Accuracy", 70);
        list.Columns.Add("Avg Time", 75);
        list.Columns.Add("Status", 85);

        foreach (GameResult g in player.History.OrderByDescending(h => h.PlayedAt))
        {
            list.Items.Add(new ListViewItem(new[]
            {
                g.PlayedAt.ToString("yyyy-MM-dd HH:mm"),
                g.Mode,
                g.Category,
                g.Difficulty,
                g.Score.ToString("N0") + " / " + g.MaxScore.ToString("N0"),
                g.Correct.ToString(),
                g.Incorrect.ToString(),
                g.Accuracy.ToString("0") + "%",
                g.AverageTime.ToString("0.0") + " s",
                g.Completed ? "Completed" : "Quit early"
            }));
        }
        root.Controls.Add(list, 0, 3);

        Button back = Theme.MakeButton("BACK", Theme.SurfaceLight, Theme.FontButton, 50);
        back.Anchor = AnchorStyles.Left;
        back.Size = new Size(160, 50);
        back.Click += (sender, e) => App.Navigate(new MainMenuScreen(App));
        root.Controls.Add(back, 0, 4);

        Controls.Add(root);
    }

    private static void AddTile(TableLayoutPanel table, int index, string caption, string value)
    {
        var tile = new Panel { Dock = DockStyle.Fill, BackColor = Theme.Surface, Margin = new Padding(5) };

        Label valueLabel = Theme.MakeFillLabel(value, 14f, FontStyle.Bold, Theme.TextColor, ContentAlignment.MiddleCenter);
        Label captionLabel = Theme.MakeFillLabel(caption, 9.5f, FontStyle.Regular, Theme.MutedText, ContentAlignment.MiddleCenter);
        captionLabel.Dock = DockStyle.Top;
        captionLabel.Height = 30;

        tile.Controls.Add(valueLabel);
        tile.Controls.Add(captionLabel);
        table.Controls.Add(tile, index % 5, index / 5);
    }
}
