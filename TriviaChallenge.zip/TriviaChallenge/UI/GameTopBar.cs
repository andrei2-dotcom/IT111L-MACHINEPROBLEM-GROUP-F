using System.Drawing;
using System.Windows.Forms;

namespace TriviaChallenge;

public class GameTopBar : TableLayoutPanel
{
    public GameTopBar()
    {
        ColumnCount = 3;
        RowCount = 2;
        BackColor = Color.Transparent;

        ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
        ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 240f));
        ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 110f));
        RowStyles.Add(new RowStyle(SizeType.Percent, 55f));
        RowStyles.Add(new RowStyle(SizeType.Percent, 45f));

        Header = Theme.MakeFillLabel("", 20f, FontStyle.Bold, Theme.Accent, ContentAlignment.MiddleLeft);
        Sub = Theme.MakeFillLabel("", 11f, FontStyle.Regular, Theme.MutedText, ContentAlignment.TopLeft);
        Score = Theme.MakeFillLabel("", 20f, FontStyle.Bold, Theme.TextColor, ContentAlignment.MiddleRight);

        Quit = Theme.MakeButton("QUIT", Theme.Bad, Theme.FontSmallBold, 38);
        Quit.Anchor = AnchorStyles.None;
        Quit.Size = new Size(96, 38);

        Controls.Add(Header, 0, 0);
        Controls.Add(Sub, 0, 1);
        Controls.Add(Score, 1, 0);
        SetRowSpan(Score, 2);
        Controls.Add(Quit, 2, 0);
        SetRowSpan(Quit, 2);
    }

    public Label Header { get; private set; }
    public Label Sub { get; private set; }
    public Label Score { get; private set; }
    public Button Quit { get; private set; }
}
