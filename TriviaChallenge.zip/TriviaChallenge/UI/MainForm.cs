using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace TriviaChallenge;

public class MainForm : Form
{
    private readonly Panel _host = new Panel { Dock = DockStyle.Fill };

    public MainForm()
    {
        Text = "Trivia Challenge";
        ClientSize = new Size(1040, 720);
        MinimumSize = new Size(980, 700);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Theme.Background;
        Font = new Font("Segoe UI", 10f);

        Controls.Add(_host);
        Navigate(new LoginScreen(this));
    }

    public void Navigate(Control screen)
    {
        List<Control> old = _host.Controls.Cast<Control>().ToList();

        SuspendLayout();
        _host.Controls.Clear();
        screen.Dock = DockStyle.Fill;
        _host.Controls.Add(screen);
        ResumeLayout(true);

        if (old.Count == 0) return;

        if (IsHandleCreated)
        {
            BeginInvoke(new Action(() =>
            {
                foreach (Control c in old) c.Dispose();
            }));
        }
        else
        {
            foreach (Control c in old) c.Dispose();
        }
    }
}
