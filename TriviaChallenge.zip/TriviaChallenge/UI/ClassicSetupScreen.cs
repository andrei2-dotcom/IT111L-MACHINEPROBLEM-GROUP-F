using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace TriviaChallenge;

public class ClassicSetupScreen : ScreenBase
{
    private readonly Player _player;
    private readonly List<RadioButton> _categoryButtons = new List<RadioButton>();
    private readonly List<RadioButton> _difficultyButtons = new List<RadioButton>();

    private static readonly Difficulty[] ClassicDifficulties = { Difficulty.Easy, Difficulty.Medium, Difficulty.Hard };

    public ClassicSetupScreen(MainForm app) : base(app)
    {
        _player = AppState.Accounts.CurrentPlayer;

        var stack = new Panel { Size = new Size(860, 560), BackColor = Color.Transparent };
        stack.Controls.Add(Theme.MakeCenteredLabel("CLASSIC TRIVIA", 28f, FontStyle.Bold, Theme.Accent, 0, 56, 860));

        Label step1 = Theme.MakeLabel("1.  Choose a category", 13f, FontStyle.Bold);
        step1.Location = new Point(0, 70);
        stack.Controls.Add(step1);

        var categoryFlow = new FlowLayoutPanel
        {
            Location = new Point(0, 104),
            Size = new Size(860, 216),
            AutoScroll = true,
            BackColor = Color.Transparent
        };
        stack.Controls.Add(categoryFlow);

        Label step2 = Theme.MakeLabel("2.  Choose a difficulty", 13f, FontStyle.Bold);
        step2.Location = new Point(0, 330);
        stack.Controls.Add(step2);

        var difficultyFlow = new FlowLayoutPanel
        {
            Location = new Point(0, 364),
            Size = new Size(860, 84),
            WrapContents = false,
            BackColor = Color.Transparent
        };
        stack.Controls.Add(difficultyFlow);

        foreach (Difficulty d in ClassicDifficulties)
        {
            RadioButton rb = MakeChoice(270);
            rb.Tag = d;
            _difficultyButtons.Add(rb);
            difficultyFlow.Controls.Add(rb);
        }

        RadioButton all = MakeChoice(190);
        all.Tag = "";
        _categoryButtons.Add(all);
        categoryFlow.Controls.Add(all);
        foreach (string category in AppState.Questions.Categories)
        {
            RadioButton rb = MakeChoice(190);
            rb.Tag = category;
            _categoryButtons.Add(rb);
            categoryFlow.Controls.Add(rb);
        }

        _categoryButtons[0].Checked = true;
        _difficultyButtons[0].Checked = true;
        RefreshLabels();

        foreach (RadioButton rb in _categoryButtons)
            rb.CheckedChanged += (sender, e) => { if (((RadioButton)sender).Checked) RefreshLabels(); };

        Button start = Theme.MakeButton("START GAME", Theme.Good, Theme.FontButton, 54);
        start.SetBounds(240, 470, 240, 54);
        start.Click += (sender, e) => StartGame();
        Button back = Theme.MakeButton("BACK", Theme.SurfaceLight, Theme.FontButton, 54);
        back.SetBounds(500, 470, 120, 54);
        back.Click += (sender, e) => App.Navigate(new MainMenuScreen(App));
        stack.Controls.Add(start);
        stack.Controls.Add(back);

        Controls.Add(stack);
        Theme.Center(stack, this);
    }

    private static RadioButton MakeChoice(int width)
    {
        var rb = new RadioButton
        {
            Appearance = Appearance.Button,
            FlatStyle = FlatStyle.Flat,
            AutoSize = false,
            Size = new Size(width, 62),
            Margin = new Padding(4),
            TextAlign = ContentAlignment.MiddleCenter,
            BackColor = Theme.SurfaceLight,
            ForeColor = Color.White,
            Font = Theme.FontSmallBold,
            Cursor = Cursors.Hand,
            UseMnemonic = false
        };
        rb.FlatAppearance.BorderSize = 0;
        rb.FlatAppearance.CheckedBackColor = Theme.Primary;
        rb.FlatAppearance.MouseOverBackColor = Theme.Primary;
        return rb;
    }

    private string SelectedCategory()
    {
        RadioButton selected = _categoryButtons.First(b => b.Checked);
        string tag = (string)selected.Tag;
        return tag.Length == 0 ? null : tag;
    }

    private Difficulty SelectedDifficulty()
    {
        return (Difficulty)_difficultyButtons.First(b => b.Checked).Tag;
    }

    private void RefreshLabels()
    {
        QuestionRepository repo = AppState.Questions;

        foreach (RadioButton rb in _categoryButtons)
        {
            string tag = (string)rb.Tag;
            string name = tag.Length == 0 ? "All Categories" : tag;
            int count = repo.Count(tag.Length == 0 ? null : tag, null);
            rb.Text = name + "\n" + count + (count == 1 ? " question" : " questions");
        }

        string category = SelectedCategory();
        foreach (RadioButton rb in _difficultyButtons)
        {
            var difficulty = (Difficulty)rb.Tag;
            bool unlocked = ProgressionSystem.IsUnlocked(_player, difficulty);
            int count = repo.Count(category, difficulty);

            rb.Enabled = unlocked;
            rb.Text = unlocked
                ? difficulty.ToDisplay() + "  (" + difficulty.BasePoints() + " pts each)\n" + count + (count == 1 ? " question" : " questions")
                : difficulty.ToDisplay() + "\n(locked - reach Level " + ProgressionSystem.RequiredLevel(difficulty) + ")";
        }
    }

    private void StartGame()
    {
        GameLauncher.StartClassic(App, SelectedCategory(), SelectedDifficulty());
    }
}
