using System;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace TriviaChallenge;

public class GameScreen : ScreenBase
{
    private readonly QuestionGameMode _mode;
    private readonly Action _replay;
    private readonly System.Windows.Forms.Timer _timer;
    private readonly Stopwatch _stopwatch = new Stopwatch();
    private readonly ToolTip _tips = new ToolTip();

    private GameTopBar _top;
    private Panel _stage;
    private TableLayoutPanel _questionPage;
    private TableLayoutPanel _feedbackPage;
    private Panel _boardPage;
    private Panel _timerPanel;
    private Panel _answerHost;
    private ProgressStrip _timerBar;
    private Label _lblTimer;
    private Label _lblQuestion;
    private Label _lblHint;
    private Label _fbTitle;
    private Label _fbAnswer;
    private Label _fbPoints;
    private Label _fbScore;
    private Button _btnNext;
    private Button _btnFifty;
    private Button _btnSkip;
    private Button _btnHint;
    private Button _btnWalk;
    private Label[] _ladderLabels;

    private Question _current;
    private bool _answered;

    public GameScreen(MainForm app, QuestionGameMode mode, Action replay) : base(app)
    {
        _mode = mode;
        _replay = replay;

        _timer = new System.Windows.Forms.Timer { Interval = 100 };
        _timer.Tick += OnTick;

        BuildLayout();
    }

    private void BuildLayout()
    {
        bool hasLadder = _mode is MillionaireMode;

        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 3,
            Padding = new Padding(24, 12, 24, 12),
            BackColor = Color.Transparent
        };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, hasLadder ? 240f : 0f));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 80f));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 74f));

        _top = new GameTopBar { Dock = DockStyle.Fill };
        _top.Quit.Click += (sender, e) => OnQuit();
        root.Controls.Add(_top, 0, 0);
        root.SetColumnSpan(_top, 2);

        _stage = new Panel { Dock = DockStyle.Fill, BackColor = Color.Transparent };
        BuildQuestionPage();
        BuildFeedbackPage();
        _boardPage = new Panel { Dock = DockStyle.Fill, BackColor = Color.Transparent, Visible = false };
        _stage.Controls.Add(_questionPage);
        _stage.Controls.Add(_feedbackPage);
        _stage.Controls.Add(_boardPage);
        root.Controls.Add(_stage, 0, 1);

        var bottom = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            BackColor = Color.Transparent,
            Padding = new Padding(0, 12, 0, 0)
        };
        _btnFifty = MakeLifelineButton("50 / 50", "Removes two wrong answers (multiple choice only).");
        _btnSkip = MakeLifelineButton("SKIP", "Skip this question without losing your place.");
        _btnHint = MakeLifelineButton("HINT", "Shows a clue about the correct answer.");
        _btnFifty.Click += (sender, e) => OnFiftyFifty();
        _btnSkip.Click += (sender, e) => OnSkip();
        _btnHint.Click += (sender, e) => OnHint();
        bottom.Controls.Add(_btnFifty);
        bottom.Controls.Add(_btnSkip);
        bottom.Controls.Add(_btnHint);

        if (hasLadder)
        {
            _btnWalk = Theme.MakeButton("WALK AWAY", Theme.Accent, Theme.FontSmallBold, 48);
            _btnWalk.ForeColor = Color.Black;
            _btnWalk.Width = 170;
            _btnWalk.Margin = new Padding(40, 0, 0, 0);
            _btnWalk.Click += (sender, e) => OnWalkAway();
            _tips.SetToolTip(_btnWalk, "Stop now and keep your current prize.");
            bottom.Controls.Add(_btnWalk);
        }
        root.Controls.Add(bottom, 0, 2);

        if (hasLadder)
        {
            Control ladder = BuildLadder();
            root.Controls.Add(ladder, 1, 1);
            root.SetRowSpan(ladder, 2);
        }

        Controls.Add(root);
        ShowPage(null);
    }

    private void BuildQuestionPage()
    {
        _questionPage = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 4,
            BackColor = Color.Transparent
        };
        _questionPage.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
        _questionPage.RowStyles.Add(new RowStyle(SizeType.Absolute, 52f));
        _questionPage.RowStyles.Add(new RowStyle(SizeType.Absolute, 130f));
        _questionPage.RowStyles.Add(new RowStyle(SizeType.Absolute, 40f));
        _questionPage.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));

        _timerPanel = new Panel { Dock = DockStyle.Fill, BackColor = Color.Transparent, Visible = false };
        _lblTimer = Theme.MakeFillLabel("", 12f, FontStyle.Bold, Theme.Accent, ContentAlignment.MiddleLeft);
        _lblTimer.Dock = DockStyle.Top;
        _lblTimer.Height = 30;
        _timerBar = new ProgressStrip { Dock = DockStyle.Bottom, Height = 12, Value = 1 };
        _timerPanel.Controls.Add(_lblTimer);
        _timerPanel.Controls.Add(_timerBar);

        _lblQuestion = Theme.MakeFillLabel("", 20f, FontStyle.Bold, Theme.TextColor, ContentAlignment.MiddleCenter);
        _lblQuestion.BackColor = Theme.Surface;
        _lblQuestion.Padding = new Padding(20, 6, 20, 6);
        _lblQuestion.Margin = new Padding(0, 6, 0, 6);

        _lblHint = Theme.MakeFillLabel("", 11f, FontStyle.Italic, Theme.Accent, ContentAlignment.MiddleLeft);

        _answerHost = new Panel { Dock = DockStyle.Fill, BackColor = Color.Transparent, Padding = new Padding(0, 4, 0, 0) };

        _questionPage.Controls.Add(_timerPanel, 0, 0);
        _questionPage.Controls.Add(_lblQuestion, 0, 1);
        _questionPage.Controls.Add(_lblHint, 0, 2);
        _questionPage.Controls.Add(_answerHost, 0, 3);
    }

    private void BuildFeedbackPage()
    {
        _feedbackPage = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 7,
            BackColor = Color.Transparent,
            Visible = false
        };
        _feedbackPage.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
        _feedbackPage.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
        _feedbackPage.RowStyles.Add(new RowStyle(SizeType.Absolute, 90f));
        _feedbackPage.RowStyles.Add(new RowStyle(SizeType.Absolute, 70f));
        _feedbackPage.RowStyles.Add(new RowStyle(SizeType.Absolute, 60f));
        _feedbackPage.RowStyles.Add(new RowStyle(SizeType.Absolute, 50f));
        _feedbackPage.RowStyles.Add(new RowStyle(SizeType.Absolute, 80f));
        _feedbackPage.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));

        _fbTitle = Theme.MakeFillLabel("", 40f, FontStyle.Bold, Theme.GoodText, ContentAlignment.MiddleCenter);
        _fbAnswer = Theme.MakeFillLabel("", 20f, FontStyle.Regular, Theme.TextColor, ContentAlignment.MiddleCenter);
        _fbPoints = Theme.MakeFillLabel("", 22f, FontStyle.Bold, Theme.Accent, ContentAlignment.MiddleCenter);
        _fbScore = Theme.MakeFillLabel("", 14f, FontStyle.Regular, Theme.MutedText, ContentAlignment.MiddleCenter);

        _btnNext = Theme.MakeButton("NEXT", Theme.Primary, Theme.FontButton, 56);
        _btnNext.Anchor = AnchorStyles.None;
        _btnNext.Size = new Size(280, 56);
        _btnNext.Click += (sender, e) => ShowNext();

        _feedbackPage.Controls.Add(_fbTitle, 0, 1);
        _feedbackPage.Controls.Add(_fbAnswer, 0, 2);
        _feedbackPage.Controls.Add(_fbPoints, 0, 3);
        _feedbackPage.Controls.Add(_fbScore, 0, 4);
        _feedbackPage.Controls.Add(_btnNext, 0, 5);
    }

    private Control BuildLadder()
    {
        int levels = MillionaireMode.Prizes.Length;
        var ladder = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = levels,
            BackColor = Theme.Surface,
            Margin = new Padding(16, 0, 0, 0),
            Padding = new Padding(8)
        };
        ladder.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
        for (int i = 0; i < levels; i++) ladder.RowStyles.Add(new RowStyle(SizeType.Percent, 100f / levels));

        _ladderLabels = new Label[levels];
        var mm = (MillionaireMode)_mode;
        for (int level = levels; level >= 1; level--)
        {
            string text = level + ".   " + MillionaireMode.Prizes[level - 1].ToString("N0");
            if (mm.IsCheckpoint(level)) text += "   (safe)";

            Label label = Theme.MakeFillLabel(text, 12f, FontStyle.Bold, Theme.MutedText, ContentAlignment.MiddleLeft);
            label.Padding = new Padding(12, 0, 0, 0);
            _ladderLabels[level - 1] = label;
            ladder.Controls.Add(label, 0, levels - level);
        }
        return ladder;
    }

    private Button MakeLifelineButton(string text, string tip)
    {
        Button button = Theme.MakeButton(text, Theme.Primary, Theme.FontSmallBold, 48);
        button.Width = 140;
        button.Margin = new Padding(0, 0, 12, 0);
        _tips.SetToolTip(button, tip);
        return button;
    }

    protected override void OnLoad(EventArgs e)
    {
        base.OnLoad(e);
        ShowNext();
    }

    private bool IsCurrentTimed
    {
        get { return _current != null && _mode.UsesTimer && _current.IsTimed; }
    }

    private void ShowPage(Control page)
    {
        _questionPage.Visible = page == _questionPage;
        _feedbackPage.Visible = page == _feedbackPage;
        _boardPage.Visible = page == _boardPage;
    }

    private void ShowNext()
    {
        if (_mode.IsFinished)
        {
            _timer.Stop();
            GameLauncher.Finish(App, _mode, _replay);
            return;
        }

        if (_mode.RequiresSelection)
        {
            ShowBoard();
            return;
        }

        LoadQuestion();
    }

    private void UpdateHeader()
    {
        _top.Header.Text = _mode.GetHeader();
        _top.Sub.Text = _mode.GetSubHeader();
        _top.Score.Text = "Score: " + _mode.Score.ToString("N0");
    }

    private void ClearAnswerHost()
    {
        foreach (Control c in _answerHost.Controls.Cast<Control>().ToList())
        {
            _answerHost.Controls.Remove(c);
            c.Dispose();
        }
    }

    private void LoadQuestion()
    {
        _current = _mode.CurrentQuestion;
        _answered = false;

        _lblQuestion.Text = _current.Text;
        _lblHint.Text = "";
        UpdateHeader();

        ClearAnswerHost();
        ShowPage(_questionPage);
        _current.DisplayQuestion(_answerHost, answer => HandleAnswer(answer, false));

        _timerPanel.Visible = IsCurrentTimed;
        if (IsCurrentTimed) UpdateTimerDisplay(_current.TimeLimitSeconds);

        RefreshLifelines(true);
        UpdateLadder();

        _stopwatch.Restart();
        if (IsCurrentTimed) _timer.Start();
    }

    private void HandleAnswer(string answer, bool timedOut)
    {
        if (_answered || _current == null) return;
        _answered = true;

        _timer.Stop();
        _stopwatch.Stop();
        _current.LockInput();

        double seconds = _stopwatch.Elapsed.TotalSeconds;
        if (IsCurrentTimed) seconds = Math.Min(seconds, _current.TimeLimitSeconds);

        AnswerOutcome outcome = _mode.SubmitAnswer(answer, seconds, timedOut);
        ShowFeedback(outcome);
    }

    private void ShowFeedback(AnswerOutcome outcome)
    {
        _fbTitle.Text = outcome.Correct ? "CORRECT!" : (outcome.TimedOut ? "TIME'S UP!" : "INCORRECT");
        _fbTitle.ForeColor = outcome.Correct ? Theme.GoodText : Theme.BadText;
        _fbAnswer.Text = outcome.Correct ? outcome.CorrectAnswer : "Correct answer: " + outcome.CorrectAnswer;
        _fbPoints.Text = outcome.Message;
        _fbScore.Text = "Current Score: " + outcome.NewScore.ToString("N0");
        _btnNext.Text = _mode.IsFinished ? "SEE RESULTS" : "NEXT";

        _top.Score.Text = "Score: " + _mode.Score.ToString("N0");
        RefreshLifelines(false);
        UpdateLadder();
        ShowPage(_feedbackPage);
    }

    private void OnTick(object sender, EventArgs e)
    {
        if (_answered || _current == null || !IsCurrentTimed) return;

        double left = _current.TimeLimitSeconds - _stopwatch.Elapsed.TotalSeconds;
        if (left <= 0)
        {
            _lblTimer.Text = "Time Remaining: 00 seconds";
            _timerBar.Value = 0;
            HandleAnswer(null, true);
            return;
        }
        UpdateTimerDisplay(left);
    }

    private void UpdateTimerDisplay(double secondsLeft)
    {
        _lblTimer.Text = "Time Remaining: " + Math.Ceiling(secondsLeft).ToString("00") + " seconds";
        _timerBar.FillColor = secondsLeft <= 5 ? Theme.Bad : Theme.Accent;
        _timerBar.Value = secondsLeft / _current.TimeLimitSeconds;
    }

    private void RefreshLifelines(bool questionActive)
    {
        LifelineSet lifelines = _mode.Lifelines;
        Theme.SetButtonEnabled(_btnFifty, questionActive && lifelines.FiftyFiftyAvailable, Theme.Primary);
        Theme.SetButtonEnabled(_btnSkip, questionActive && lifelines.SkipAvailable, Theme.Primary);
        Theme.SetButtonEnabled(_btnHint, questionActive && lifelines.HintAvailable, Theme.Primary);
        if (_btnWalk != null) Theme.SetButtonEnabled(_btnWalk, _mode.CanWalkAway, Theme.Accent);
    }

    private void OnFiftyFifty()
    {
        if (_answered || _current == null || !_mode.Lifelines.FiftyFiftyAvailable) return;

        if (!_current.SupportsFiftyFifty)
        {
            _lblHint.Text = "50/50 only works on multiple-choice questions with four or more choices.";
            return;
        }

        _mode.Lifelines.UseFiftyFifty();
        _current.ApplyFiftyFifty();
        RefreshLifelines(true);
    }

    private void OnSkip()
    {
        if (_answered || _current == null || !_mode.Lifelines.SkipAvailable) return;

        if (!_mode.CanSkip)
        {
            _lblHint.Text = "There is no spare question available to skip to.";
            return;
        }

        _mode.Lifelines.UseSkip();
        _answered = true;
        _timer.Stop();
        _stopwatch.Stop();
        _current.LockInput();
        _mode.SkipCurrent();
        ShowNext();
    }

    private void OnHint()
    {
        if (_answered || _current == null || !_mode.Lifelines.HintAvailable) return;

        _mode.Lifelines.UseHint();
        _lblHint.Text = "Hint: " + _current.GetHint();
        RefreshLifelines(true);
    }

    private bool ConfirmWhilePaused(string text, string caption)
    {
        bool timerWasRunning = _timer.Enabled;
        _timer.Stop();
        _stopwatch.Stop();

        bool yes = MessageBox.Show(text, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes;

        if (!yes && timerWasRunning)
        {
            _stopwatch.Start();
            _timer.Start();
        }
        return yes;
    }

    private void OnWalkAway()
    {
        if (!_mode.CanWalkAway) return;
        if (!ConfirmWhilePaused("Walk away and keep " + _mode.Score.ToString("N0") + "?", "Walk Away")) return;

        _mode.WalkAway();
        GameLauncher.Finish(App, _mode, _replay);
    }

    private void OnQuit()
    {
        string text = _mode.AnswerCount > 0
            ? "Quit this game? Your progress so far will be saved."
            : "Quit this game?";
        if (!ConfirmWhilePaused(text, "Quit")) return;

        GameLauncher.QuitToMenu(App, _mode);
    }

    private void UpdateLadder()
    {
        var mm = _mode as MillionaireMode;
        if (mm == null || _ladderLabels == null) return;

        for (int level = 1; level <= _ladderLabels.Length; level++)
        {
            Label label = _ladderLabels[level - 1];
            bool isCurrent = !mm.IsFinished && level == mm.CurrentLevel;
            bool done = level <= mm.CompletedLevels;

            label.BackColor = isCurrent ? Theme.Accent : Color.Transparent;
            if (isCurrent) label.ForeColor = Color.Black;
            else if (done) label.ForeColor = Theme.GoodText;
            else label.ForeColor = mm.IsCheckpoint(level) ? Color.White : Theme.MutedText;
        }
    }

    private void ShowBoard()
    {
        var jeopardy = _mode as JeopardyMode;
        if (jeopardy == null) return;

        _current = null;
        _answered = true;
        UpdateHeader();
        RefreshLifelines(false);

        foreach (Control c in _boardPage.Controls.Cast<Control>().ToList())
        {
            _boardPage.Controls.Remove(c);
            c.Dispose();
        }

        int columns = jeopardy.Categories.Count;
        int rows = JeopardyMode.Values.Length;

        var table = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = columns,
            RowCount = rows + 1,
            BackColor = Color.Transparent
        };
        for (int c = 0; c < columns; c++) table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / columns));
        table.RowStyles.Add(new RowStyle(SizeType.Absolute, 70f));
        for (int r = 0; r < rows; r++) table.RowStyles.Add(new RowStyle(SizeType.Percent, 100f / rows));

        for (int c = 0; c < columns; c++)
        {
            Label header = Theme.MakeFillLabel(jeopardy.Categories[c].ToUpperInvariant(), 13f, FontStyle.Bold,
                                               Theme.Accent, ContentAlignment.MiddleCenter);
            header.BackColor = Theme.Surface;
            header.Margin = new Padding(4);
            table.Controls.Add(header, c, 0);

            for (int r = 0; r < rows; r++)
            {
                JeopardyCell cell = jeopardy.GetCell(c, r);
                Button button = Theme.MakeButton(cell.IsPlayable ? cell.Value.ToString() : "",
                                                 cell.IsPlayable ? Theme.Primary : Theme.Disabled, Theme.FontBoard);
                button.Dock = DockStyle.Fill;
                button.Margin = new Padding(4);
                button.Enabled = cell.IsPlayable;

                int column = c;
                int row = r;
                button.Click += (sender, e) =>
                {
                    jeopardy.Select(column, row);
                    LoadQuestion();
                };
                table.Controls.Add(button, c, r + 1);
            }
        }

        _boardPage.Controls.Add(table);
        ShowPage(_boardPage);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _timer.Stop();
            _timer.Dispose();
            _tips.Dispose();
        }
        base.Dispose(disposing);
    }
}
