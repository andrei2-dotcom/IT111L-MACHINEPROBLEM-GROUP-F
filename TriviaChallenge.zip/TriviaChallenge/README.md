# Trivia Challenge (C# WinForms)

A starter implementation of the Group F Machine Problem proposal.

## Requirements
- Windows
- Visual Studio 2022 (or newer) with the **.NET desktop development** workload
- .NET 8 SDK

## Run
1. Extract the ZIP.
2. Open `TriviaChallenge.csproj` in Visual Studio.
3. If prompted, allow Visual Studio to restore the project.
4. Set `TriviaChallenge` as the startup project.
5. Press **F5**.

## Included in this first development phase
- Registration and login
- Local JSON account storage
- Password hashing with PBKDF2
- Main menu and player profile
- Classic Trivia setup (category and difficulty)
- Jeopardy Mode with a 4-category, 3-value question board
- Multiple-choice, true/false, identification, and timed questions
- Answer validation and scoring
- XP, levels, high score, and game history
- OOP examples using encapsulation, abstraction, inheritance, and polymorphism

## Notes
- User data is stored in `Data/users.json` under the application's output folder.
- Connection Mode and Millionaire Mode are still planned for later phases.
- The initial question bank is deliberately small and can be expanded in `Models/QuestionBank.cs`.
- This is a development starter, not yet the complete final machine problem.

## Phase 2: Jeopardy Mode
- Board categories: Science, History, Technology, and Sports.
- Each category has 100, 200, and 300 point questions.
- Each board tile can be selected only once.
- Correct answers award the selected tile value; incorrect answers award zero.
- Results are saved to the player's game history and performance totals.
