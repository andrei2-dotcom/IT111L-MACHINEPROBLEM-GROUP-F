using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace TriviaChallenge;

internal class QuestionDto
{
    public string Type { get; set; }
    public string Category { get; set; }
    public string Difficulty { get; set; }
    public string Text { get; set; }
    public List<string> Choices { get; set; }
    public JsonElement Answer { get; set; }
    public List<string> AcceptedAnswers { get; set; }
    public string Hint { get; set; }
    public int TimeLimit { get; set; }
}

internal class ConnectionDto
{
    public string Category { get; set; }
    public List<string> Clues { get; set; }
    public string Answer { get; set; }
    public List<string> AcceptedAnswers { get; set; }
}

internal class QuestionFileDto
{
    public List<QuestionDto> Questions { get; set; }
    public List<ConnectionDto> Connections { get; set; }
}

public class QuestionRepository
{
    private readonly List<Question> _questions = new List<Question>();
    private readonly List<ConnectionPuzzle> _puzzles = new List<ConnectionPuzzle>();

    public IReadOnlyList<Question> Questions { get { return _questions; } }
    public IReadOnlyList<ConnectionPuzzle> Puzzles { get { return _puzzles; } }
    public int QuestionCount { get { return _questions.Count; } }
    public int PuzzleCount { get { return _puzzles.Count; } }

    public List<string> Warnings { get; } = new List<string>();
    public string FilePath { get; private set; }

    public IReadOnlyList<string> Categories
    {
        get
        {
            return QuestionCategories.Defaults
                .Concat(_questions.Select(q => q.Category))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();
        }
    }

    public IEnumerable<Question> Find(string category, Difficulty? difficulty)
    {
        return _questions.Where(q =>
            (category == null || string.Equals(q.Category, category, StringComparison.OrdinalIgnoreCase)) &&
            (!difficulty.HasValue || q.Difficulty == difficulty.Value));
    }

    public int Count(string category, Difficulty? difficulty)
    {
        return Find(category, difficulty).Count();
    }

    public void Load(string path)
    {
        FilePath = path;
        _questions.Clear();
        _puzzles.Clear();
        Warnings.Clear();

        if (!File.Exists(path))
        {
            Warnings.Add("Question file not found: " + path);
            return;
        }

        string json = File.ReadAllText(path);
        if (string.IsNullOrWhiteSpace(json)) return;

        QuestionFileDto file;
        try
        {
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true,
                ReadCommentHandling = JsonCommentHandling.Skip,
                AllowTrailingCommas = true
            };

            if (json.TrimStart().StartsWith("["))
                file = new QuestionFileDto { Questions = JsonSerializer.Deserialize<List<QuestionDto>>(json, options) };
            else
                file = JsonSerializer.Deserialize<QuestionFileDto>(json, options);
        }
        catch (JsonException ex)
        {
            Warnings.Add("questions.json could not be read: " + ex.Message);
            return;
        }

        if (file == null) return;

        if (file.Questions != null)
        {
            for (int i = 0; i < file.Questions.Count; i++)
            {
                try
                {
                    _questions.Add(BuildQuestion(file.Questions[i]));
                }
                catch (FormatException ex)
                {
                    Warnings.Add("Question #" + (i + 1) + " skipped: " + ex.Message);
                }
            }
        }

        if (file.Connections != null)
        {
            for (int i = 0; i < file.Connections.Count; i++)
            {
                try
                {
                    _puzzles.Add(BuildPuzzle(file.Connections[i]));
                }
                catch (FormatException ex)
                {
                    Warnings.Add("Connection #" + (i + 1) + " skipped: " + ex.Message);
                }
            }
        }
    }

    private static Question BuildQuestion(QuestionDto d)
    {
        if (d == null) throw new FormatException("empty entry.");

        string text = (d.Text ?? "").Trim();
        if (text.Length == 0) throw new FormatException("missing \"text\".");

        string answer = AnswerToString(d.Answer);
        if (string.IsNullOrWhiteSpace(answer)) throw new FormatException("missing \"answer\".");
        answer = answer.Trim();

        string category = NormalizeCategory(d.Category);

        Difficulty difficulty = Difficulty.Easy;
        if (!string.IsNullOrWhiteSpace(d.Difficulty) && !DifficultyExtensions.TryParseLabel(d.Difficulty, out difficulty))
            throw new FormatException("unknown difficulty \"" + d.Difficulty + "\" (use Easy, Medium, Hard or VeryHard).");

        List<string> choices = (d.Choices ?? new List<string>())
            .Where(c => !string.IsNullOrWhiteSpace(c))
            .Select(c => c.Trim())
            .ToList();

        string type = (d.Type ?? "").Replace(" ", "").Replace("_", "").Replace("-", "").ToLowerInvariant();
        if (type.Length == 0)
        {
            if (choices.Count >= 2) type = "multiplechoice";
            else if (ParseBool(answer).HasValue) type = "truefalse";
            else type = "identification";
        }

        Question question;
        switch (type)
        {
            case "multiplechoice":
            case "mc":
            {
                if (choices.Count < 2) throw new FormatException("multiple choice needs at least 2 \"choices\".");
                if (choices.Select(c => c.ToLowerInvariant()).Distinct().Count() != choices.Count)
                    throw new FormatException("\"choices\" must all be different.");
                string match = choices.FirstOrDefault(c => c.Equals(answer, StringComparison.OrdinalIgnoreCase));
                if (match == null) throw new FormatException("\"answer\" must be one of the \"choices\".");
                question = new MultipleChoiceQuestion(text, category, difficulty, choices, match, d.Hint, d.AcceptedAnswers);
                break;
            }
            case "truefalse":
            case "tf":
            {
                bool? value = ParseBool(answer);
                if (!value.HasValue) throw new FormatException("true/false \"answer\" must be true or false.");
                question = new TrueFalseQuestion(text, category, difficulty, value.Value, d.Hint);
                break;
            }
            case "identification":
            case "id":
            {
                question = new IdentificationQuestion(text, category, difficulty, answer, d.Hint, d.AcceptedAnswers);
                break;
            }
            default:
                throw new FormatException("unknown type \"" + d.Type + "\" (use MultipleChoice, TrueFalse or Identification).");
        }

        if (d.TimeLimit > 0) question = new TimedQuestion(question, d.TimeLimit);
        return question;
    }

    private static ConnectionPuzzle BuildPuzzle(ConnectionDto d)
    {
        if (d == null) throw new FormatException("empty entry.");
        if (string.IsNullOrWhiteSpace(d.Answer)) throw new FormatException("missing \"answer\".");

        List<string> clues = (d.Clues ?? new List<string>())
            .Where(c => !string.IsNullOrWhiteSpace(c))
            .Select(c => c.Trim())
            .Take(4)
            .ToList();
        if (clues.Count < 3) throw new FormatException("needs at least 3 \"clues\".");

        return new ConnectionPuzzle(d.Category, clues, d.Answer.Trim(), d.AcceptedAnswers);
    }

    private static string NormalizeCategory(string category)
    {
        string trimmed = (category ?? "").Trim();
        if (trimmed.Length == 0) return "General Knowledge";
        string known = QuestionCategories.Defaults.FirstOrDefault(c => c.Equals(trimmed, StringComparison.OrdinalIgnoreCase));
        return known ?? trimmed;
    }

    private static string AnswerToString(JsonElement element)
    {
        switch (element.ValueKind)
        {
            case JsonValueKind.String: return element.GetString();
            case JsonValueKind.True: return "True";
            case JsonValueKind.False: return "False";
            case JsonValueKind.Number: return element.GetRawText();
            default: return null;
        }
    }

    private static bool? ParseBool(string text)
    {
        switch ((text ?? "").Trim().ToLowerInvariant())
        {
            case "true": case "t": case "yes": case "y": return true;
            case "false": case "f": case "no": case "n": return false;
            default: return null;
        }
    }
}
