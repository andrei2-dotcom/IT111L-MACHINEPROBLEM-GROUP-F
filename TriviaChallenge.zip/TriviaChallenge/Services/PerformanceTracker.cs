using System;
using System.Collections.Generic;
using System.Linq;

namespace TriviaChallenge;

public class PerformanceSummary
{
    public int HighScore { get; set; }
    public int GamesPlayed { get; set; }
    public int QuestionsAnswered { get; set; }
    public int Correct { get; set; }
    public int Incorrect { get; set; }
    public double Accuracy { get; set; }
    public double? FastestAnswer { get; set; }
    public string BestCategory { get; set; }
    public string BestMode { get; set; }
    public string HighestDifficulty { get; set; }
}

public class PerformanceTracker
{
    private readonly AccountManager _accounts;

    public PerformanceTracker(AccountManager accounts)
    {
        _accounts = accounts;
    }

    public void RecordGame(Player player, GameResult result)
    {
        player.AddResult(result);
        _accounts.Save();
    }

    public static double CalculateAccuracy(int correct, int total)
    {
        return total == 0 ? 0 : correct * 100.0 / total;
    }

    public PerformanceSummary Summarize(Player player)
    {
        IReadOnlyList<GameResult> history = player.History;
        List<AnswerRecord> answers = history.SelectMany(g => g.Answers).ToList();
        int correct = answers.Count(a => a.Correct);

        var summary = new PerformanceSummary
        {
            HighScore = player.HighScore,
            GamesPlayed = history.Count,
            QuestionsAnswered = answers.Count,
            Correct = correct,
            Incorrect = answers.Count - correct,
            Accuracy = CalculateAccuracy(correct, answers.Count),
            FastestAnswer = answers.Where(a => a.Correct).Select(a => (double?)a.Seconds).Min(),
            BestCategory = BestCategory(answers),
            BestMode = BestMode(history),
            HighestDifficulty = HighestDifficulty(answers)
        };
        return summary;
    }

    private static string BestCategory(List<AnswerRecord> answers)
    {
        var groups = answers.GroupBy(a => a.Category)
            .Select(g => new { Name = g.Key, Total = g.Count(), Percent = CalculateAccuracy(g.Count(a => a.Correct), g.Count()) })
            .ToList();
        return PickBest(groups.Select(g => Tuple.Create(g.Name, g.Total, g.Percent)).ToList());
    }

    private static string BestMode(IReadOnlyList<GameResult> history)
    {
        var groups = history.GroupBy(g => g.Mode)
            .Select(g =>
            {
                int total = g.Sum(x => x.Correct + x.Incorrect);
                return Tuple.Create(g.Key, total, CalculateAccuracy(g.Sum(x => x.Correct), total));
            })
            .Where(t => t.Item2 > 0)
            .ToList();
        return PickBest(groups);
    }

    private static string PickBest(List<Tuple<string, int, double>> groups)
    {
        if (groups.Count == 0) return "N/A";
        List<Tuple<string, int, double>> eligible = groups.Where(g => g.Item2 >= 3).ToList();
        if (eligible.Count == 0) eligible = groups;
        Tuple<string, int, double> best = eligible.OrderByDescending(g => g.Item3).ThenByDescending(g => g.Item2).First();
        return best.Item1 + " (" + best.Item3.ToString("0") + "%)";
    }

    private static string HighestDifficulty(List<AnswerRecord> answers)
    {
        Difficulty? highest = null;
        foreach (AnswerRecord a in answers.Where(x => x.Correct))
        {
            Difficulty parsed;
            if (DifficultyExtensions.TryParseLabel(a.Difficulty, out parsed) && (!highest.HasValue || parsed > highest.Value))
                highest = parsed;
        }
        return highest.HasValue ? highest.Value.ToDisplay() : "N/A";
    }
}
