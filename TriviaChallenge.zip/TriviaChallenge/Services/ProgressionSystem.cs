using System;
using System.Collections.Generic;

namespace TriviaChallenge;

public static class ProgressionSystem
{
    public static readonly int[] LevelThresholds = { 0, 100, 250, 500, 1000 };
    public static readonly string[] Titles = { "Rookie", "Apprentice", "Scholar", "Expert", "Trivia Master" };

    public static bool UnlocksEnabled = true;

    public static int MaxLevel { get { return LevelThresholds.Length; } }

    public static int GetLevel(int xp)
    {
        int level = 1;
        for (int i = 0; i < LevelThresholds.Length; i++)
            if (xp >= LevelThresholds[i]) level = i + 1;
        return level;
    }

    public static string GetTitle(int level)
    {
        int index = Math.Min(Math.Max(level, 1), Titles.Length) - 1;
        return Titles[index];
    }

    public static int XpForCurrentLevel(int level) { return LevelThresholds[level - 1]; }

    public static int XpForNextLevel(int level)
    {
        return level >= MaxLevel ? -1 : LevelThresholds[level];
    }

    public static int CalculateXp(GameResult result)
    {
        int answered = result.Correct + result.Incorrect;
        int xp = result.Correct * 8;
        if (answered >= 3 && result.Accuracy >= 80) xp += 20;
        return xp;
    }

    public static int RequiredLevel(string mode)
    {
        switch (mode)
        {
            case ModeNames.Jeopardy: return 2;
            case ModeNames.Connection: return 3;
            case ModeNames.Millionaire: return 4;
            default: return 1;
        }
    }

    public static int RequiredLevel(Difficulty difficulty)
    {
        switch (difficulty)
        {
            case Difficulty.Hard: return 2;
            case Difficulty.VeryHard: return 4;
            default: return 1;
        }
    }

    public static bool IsUnlocked(Player player, string mode)
    {
        return !UnlocksEnabled || player.Level >= RequiredLevel(mode);
    }

    public static bool IsUnlocked(Player player, Difficulty difficulty)
    {
        return !UnlocksEnabled || player.Level >= RequiredLevel(difficulty);
    }

    public static List<string> UnlocksAtLevel(int level)
    {
        var list = new List<string>();
        foreach (string mode in ModeNames.All)
            if (RequiredLevel(mode) == level && level > 1) list.Add(mode + " unlocked");
        foreach (Difficulty d in new[] { Difficulty.Hard })
            if (RequiredLevel(d) == level && level > 1) list.Add(d.ToDisplay() + " difficulty unlocked");
        return list;
    }
}
