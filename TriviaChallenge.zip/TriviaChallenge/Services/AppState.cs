using System;
using System.IO;

namespace TriviaChallenge;

public static class AppState
{
    public static QuestionRepository Questions { get; private set; }
    public static AccountManager Accounts { get; private set; }
    public static PerformanceTracker Tracker { get; private set; }

    public static string QuestionFilePath
    {
        get { return Path.Combine(AppContext.BaseDirectory, "Data", "questions.json"); }
    }

    public static string PlayerFilePath
    {
        get
        {
            string root = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            return Path.Combine(root, "TriviaChallenge", "players.json");
        }
    }

    public static void Initialize()
    {
        Questions = new QuestionRepository();
        Questions.Load(QuestionFilePath);

        Accounts = new AccountManager(PlayerFilePath);
        Tracker = new PerformanceTracker(Accounts);
    }
}
