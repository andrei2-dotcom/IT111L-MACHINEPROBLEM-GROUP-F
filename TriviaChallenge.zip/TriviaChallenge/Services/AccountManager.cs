using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace TriviaChallenge;

public class AccountManager
{
    private static readonly JsonSerializerOptions JsonOptions = new JsonSerializerOptions { WriteIndented = true };

    private readonly string _filePath;
    private readonly List<Player> _players = new List<Player>();

    public AccountManager(string filePath)
    {
        _filePath = filePath;
        Load();
    }

    public Player CurrentPlayer { get; private set; }
    public bool IsLoggedIn { get { return CurrentPlayer != null; } }
    public string LastError { get; private set; }

    public (bool Success, string Message) Register(string username, string password, string confirm)
    {
        username = (username ?? "").Trim();

        if (username.Length < 3 || username.Length > 20)
            return (false, "Username must be 3 to 20 characters long.");
        if (!username.All(c => char.IsLetterOrDigit(c) || c == '_'))
            return (false, "Username may only contain letters, numbers and underscores.");
        if (string.IsNullOrEmpty(password) || password.Length < 4)
            return (false, "Password must be at least 4 characters long.");
        if (password != confirm)
            return (false, "The passwords do not match.");
        if (_players.Any(p => string.Equals(p.Username, username, StringComparison.OrdinalIgnoreCase)))
            return (false, "That username is already taken.");

        _players.Add(Player.Create(username, password));
        Save();
        return (true, "Account created! You can now log in.");
    }

    public (bool Success, string Message) Login(string username, string password)
    {
        username = (username ?? "").Trim();
        Player player = _players.FirstOrDefault(p => string.Equals(p.Username, username, StringComparison.OrdinalIgnoreCase));

        if (player == null || !player.VerifyPassword(password ?? ""))
            return (false, "Invalid username or password.");

        CurrentPlayer = player;
        return (true, "Welcome back, " + player.Username + "!");
    }

    public void Logout()
    {
        CurrentPlayer = null;
    }

    public void Save()
    {
        try
        {
            string directory = Path.GetDirectoryName(_filePath);
            if (!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);

            List<PlayerData> data = _players.Select(p => p.ToData()).ToList();
            File.WriteAllText(_filePath, JsonSerializer.Serialize(data, JsonOptions));
            LastError = null;
        }
        catch (Exception ex)
        {
            LastError = ex.Message;
        }
    }

    private void Load()
    {
        if (!File.Exists(_filePath)) return;

        try
        {
            string json = File.ReadAllText(_filePath);
            if (string.IsNullOrWhiteSpace(json)) return;

            List<PlayerData> data = JsonSerializer.Deserialize<List<PlayerData>>(json);
            if (data != null)
                foreach (PlayerData d in data) _players.Add(Player.FromData(d));
        }
        catch (Exception)
        {
            _players.Clear();
            try { File.Move(_filePath, _filePath + ".corrupt", true); } catch (Exception) { }
        }
    }
}
