using System;
using System.Drawing;
using System.Windows.Forms;

namespace TriviaChallenge;

public class TrueFalseQuestion : Question
{
    public TrueFalseQuestion(string text, string category, Difficulty difficulty,
                             bool isTrue, string hint = null)
        : base(text, category, difficulty, isTrue ? "True" : "False", hint, null)
    {
    }

    public override void DisplayQuestion(Control host, Action<string> onAnswerSelected)
    {
        ResetInput();

        var table = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            ColumnCount = 2,
            RowCount = 1,
            Height = 110,
            BackColor = Color.Transparent
        };
        table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
        table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
        table.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));

        Button trueButton = Theme.MakeButton("TRUE", Theme.Primary, Theme.FontBoard);
        Button falseButton = Theme.MakeButton("FALSE", Theme.Primary, Theme.FontBoard);
        foreach (Button b in new[] { trueButton, falseButton })
        {
            b.Dock = DockStyle.Fill;
            b.Margin = new Padding(6, 0, 6, 8);
            InputControls.Add(b);
        }

        trueButton.Click += (sender, e) => onAnswerSelected("True");
        falseButton.Click += (sender, e) => onAnswerSelected("False");

        table.Controls.Add(trueButton, 0, 0);
        table.Controls.Add(falseButton, 1, 0);
        host.Controls.Add(table);
    }

    public override bool CheckAnswer(string playerAnswer)
    {
        return Normalize(playerAnswer) == Normalize(CorrectAnswer);
    }

    public override string FormatCorrectAnswer()
    {
        return CorrectAnswer.ToUpperInvariant();
    }

    protected override string BuildAutoHint()
    {
        return "Read the statement carefully - watch out for absolute words like \"always\" or \"never\".";
    }
}
