using System;
using System.Collections.Generic;
using System.Linq;

namespace TriviaChallenge;

public class PlayerData
{
    public string Username { get; set; } = "";
    public string Salt { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public List<GameResult> History { get; set; } = new List<GameResult>();
}

public class Player
{
    private readonly string _username;
    private readonly string _salt;
    private readonly string _passwordHash;
    private readonly List<GameResult> _history;

    private Player(string username, string salt, string passwordHash, List<GameResult> history)
    {
        _username = username;
        _salt = salt;
        _passwordHash = passwordHash;
        _history = history;
    }

    public static Player Create(string username, string password)
    {
        string salt;
        string hash = PasswordHasher.Hash(password, out salt);
        return new Player(username, salt, hash, new List<GameResult>());
    }

    public static Player FromData(PlayerData data)
    {
        return new Player(data.Username, data.Salt, data.PasswordHash,
                          data.History ?? new List<GameResult>());
    }

    public PlayerData ToData()
    {
        return new PlayerData
        {
            Username = _username,
            Salt = _salt,
            PasswordHash = _passwordHash,
            History = _history.ToList()
        };
    }

    public string Username { get { return _username; } }
    public IReadOnlyList<GameResult> History { get { return _history; } }

    public int Xp { get { return _history.Sum(g => g.XpEarned); } }
    public int Level { get { return ProgressionSystem.GetLevel(Xp); } }
    public string Title { get { return ProgressionSystem.GetTitle(Level); } }

    public int HighScore { get { return _history.Count == 0 ? 0 : _history.Max(g => g.Score); } }

    public int GetHighScore(string mode)
    {
        List<int> scores = _history.Where(g => g.Mode == mode).Select(g => g.Score).ToList();
        return scores.Count == 0 ? 0 : scores.Max();
    }

    public bool VerifyPassword(string password)
    {
        return PasswordHasher.Verify(password, _salt, _passwordHash);
    }

    public void AddResult(GameResult result)
    {
        result.NewHighScore = result.Score > 0 && result.Score > GetHighScore(result.Mode);
        result.XpEarned = ProgressionSystem.CalculateXp(result);
        _history.Add(result);
    }
}
