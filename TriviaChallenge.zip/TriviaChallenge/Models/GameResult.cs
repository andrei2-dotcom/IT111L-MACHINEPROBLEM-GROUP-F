using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace TriviaChallenge;

public class AnswerRecord
{
    public string Category { get; set; } = "";
    public string Difficulty { get; set; } = "";
    public bool Correct { get; set; }
    public double Seconds { get; set; }
    public int Points { get; set; }
}

public class GameResult
{
    public DateTime PlayedAt { get; set; }
    public string Mode { get; set; } = "";
    public string Category { get; set; } = "";
    public string Difficulty { get; set; } = "";
    public int Score { get; set; }
    public int MaxScore { get; set; }
    public int Correct { get; set; }
    public int Incorrect { get; set; }
    public double AverageTime { get; set; }
    public int XpEarned { get; set; }
    public bool NewHighScore { get; set; }
    public bool Completed { get; set; }
    public List<AnswerRecord> Answers { get; set; } = new List<AnswerRecord>();

    [JsonIgnore]
    public double Accuracy
    {
        get
        {
            int total = Correct + Incorrect;
            return total == 0 ? 0 : Correct * 100.0 / total;
        }
    }
}
