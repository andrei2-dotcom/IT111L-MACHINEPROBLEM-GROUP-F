using System.Collections.Generic;
using System.Linq;

namespace TriviaChallenge;

public class ConnectionPuzzle
{
    private readonly List<string> _clues;
    private readonly List<string> _acceptedAnswers;

    public ConnectionPuzzle(string category, IEnumerable<string> clues, string answer,
                            IEnumerable<string> acceptedAnswers)
    {
        Category = string.IsNullOrWhiteSpace(category) ? "Connections" : category;
        _clues = clues.ToList();
        Answer = answer;
        _acceptedAnswers = acceptedAnswers == null
            ? new List<string>()
            : acceptedAnswers.Where(a => !string.IsNullOrWhiteSpace(a)).ToList();
    }

    public string Category { get; }
    public string Answer { get; }
    public IReadOnlyList<string> Clues { get { return _clues; } }

    public bool CheckAnswer(string guess)
    {
        string given = Question.Normalize(guess);
        if (given.Length == 0) return false;
        if (given == Question.Normalize(Answer)) return true;
        return _acceptedAnswers.Any(a => Question.Normalize(a) == given);
    }

    public static int PointsForClues(int cluesUsed)
    {
        if (cluesUsed <= 2) return 40;
        if (cluesUsed == 3) return 30;
        return 20;
    }
}
