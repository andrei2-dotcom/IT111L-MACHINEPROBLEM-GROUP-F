using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace TriviaChallenge;

public class MultipleChoiceQuestion : Question
{
    private readonly List<string> _choices;
    private readonly Dictionary<string, Button> _buttons = new Dictionary<string, Button>();

    public MultipleChoiceQuestion(string text, string category, Difficulty difficulty,
                                  IEnumerable<string> choices, string correctAnswer,
                                  string hint = null, IEnumerable<string> acceptedAnswers = null)
        : base(text, category, difficulty, correctAnswer, hint, acceptedAnswers)
    {
        _choices = choices.ToList();
    }

    public IReadOnlyList<string> Choices { get { return _choices; } }

    public override bool SupportsFiftyFifty { get { return _choices.Count >= 4; } }

    public override void DisplayQuestion(Control host, Action<string> onAnswerSelected)
    {
        ResetInput();
        _buttons.Clear();

        List<string> order = RandomHelper.Shuffle(_choices);
        const int rowHeight = 62;

        var table = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            ColumnCount = 1,
            RowCount = order.Count,
            Height = order.Count * rowHeight,
            BackColor = Color.Transparent
        };
        table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));

        for (int i = 0; i < order.Count; i++)
        {
            string choice = order[i];
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, rowHeight));

            Button button = Theme.MakeButton(string.Format("{0}.   {1}", (char)('A' + i), choice),
                                             Theme.Primary, Theme.FontBody);
            button.Dock = DockStyle.Fill;
            button.Margin = new Padding(0, 0, 0, 8);
            button.TextAlign = ContentAlignment.MiddleLeft;
            button.Padding = new Padding(18, 0, 0, 0);
            button.Click += (sender, e) => onAnswerSelected(choice);

            _buttons[choice] = button;
            InputControls.Add(button);
            table.Controls.Add(button, 0, i);
        }

        host.Controls.Add(table);
    }

    public override bool CheckAnswer(string playerAnswer)
    {
        return Normalize(playerAnswer) == Normalize(CorrectAnswer);
    }

    public override void ApplyFiftyFifty()
    {
        List<string> wrong = _buttons
            .Where(pair => Normalize(pair.Key) != Normalize(CorrectAnswer) && pair.Value.Visible)
            .Select(pair => pair.Key)
            .ToList();

        foreach (string key in RandomHelper.Shuffle(wrong).Take(2))
            _buttons[key].Visible = false;
    }

    protected override string BuildAutoHint()
    {
        return "The correct answer starts with the letter \"" + CorrectAnswer[0] + "\".";
    }
}
