using System;
using System.Collections.Generic;
using System.Linq;

namespace TriviaChallenge;

public enum Difficulty
{
    Easy = 1,
    Medium = 2,
    Hard = 3,
    VeryHard = 4
}

public static class DifficultyExtensions
{
    public static int BasePoints(this Difficulty d)
    {
        switch (d)
        {
            case Difficulty.Easy: return 10;
            case Difficulty.Medium: return 20;
            case Difficulty.Hard: return 30;
            case Difficulty.VeryHard: return 40;
            default: return 10;
        }
    }

    public static string ToDisplay(this Difficulty d)
    {
        return d == Difficulty.VeryHard ? "Very Hard" : d.ToString();
    }

    public static bool TryParseLabel(string label, out Difficulty difficulty)
    {
        string cleaned = (label ?? "").Replace(" ", "").Replace("_", "").Replace("-", "");
        return Enum.TryParse(cleaned, true, out difficulty);
    }
}

public static class ModeNames
{
    public const string Classic = "Classic Trivia";
    public const string Jeopardy = "Jeopardy Mode";
    public const string Connection = "Connection Mode";
    public const string Millionaire = "Millionaire Mode";

    public static readonly string[] All = { Classic, Jeopardy, Connection, Millionaire };
}

public static class QuestionCategories
{
    public static readonly string[] Defaults =
    {
        "Science", "History", "Geography", "Technology",
        "Mathematics", "Entertainment", "Sports", "General Knowledge"
    };
}

public static class RandomHelper
{
    public static readonly Random Rng = new Random();

    public static List<T> Shuffle<T>(IEnumerable<T> source)
    {
        List<T> list = source.ToList();
        for (int i = list.Count - 1; i > 0; i--)
        {
            int j = Rng.Next(i + 1);
            T temp = list[i];
            list[i] = list[j];
            list[j] = temp;
        }
        return list;
    }
}
