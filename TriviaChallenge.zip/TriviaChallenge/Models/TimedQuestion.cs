using System;
using System.Windows.Forms;

namespace TriviaChallenge;

public class TimedQuestion : Question
{
    private readonly Question _inner;
    private readonly int _seconds;

    public TimedQuestion(Question inner, int seconds)
        : base(inner.Text, inner.Category, inner.Difficulty, inner.CorrectAnswer, inner.Hint, inner.AcceptedAnswers)
    {
        _inner = inner;
        _seconds = seconds;
    }

    public override int TimeLimitSeconds { get { return _seconds; } }
    public override bool SupportsFiftyFifty { get { return _inner.SupportsFiftyFifty; } }
    public override int MaxPoints { get { return Points + CalculateSpeedBonus(0); } }

    public override void DisplayQuestion(Control host, Action<string> onAnswerSelected)
    {
        _inner.DisplayQuestion(host, onAnswerSelected);
    }

    public override bool CheckAnswer(string playerAnswer) { return _inner.CheckAnswer(playerAnswer); }
    public override void ApplyFiftyFifty() { _inner.ApplyFiftyFifty(); }
    public override void LockInput() { _inner.LockInput(); }
    public override string FormatCorrectAnswer() { return _inner.FormatCorrectAnswer(); }
    protected override string BuildAutoHint() { return _inner.GetHint(); }

    public override int CalculateSpeedBonus(double secondsTaken)
    {
        if (_seconds <= 0) return 0;
        double remaining = Math.Max(0, _seconds - Math.Max(0, secondsTaken));
        double maxBonus = Points * 0.5;
        return (int)Math.Round(maxBonus * remaining / _seconds);
    }
}
