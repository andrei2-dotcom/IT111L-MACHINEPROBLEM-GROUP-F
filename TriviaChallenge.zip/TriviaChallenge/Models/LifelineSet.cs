namespace TriviaChallenge;

public class LifelineSet
{
    public bool FiftyFiftyAvailable { get; private set; } = true;
    public bool SkipAvailable { get; private set; } = true;
    public bool HintAvailable { get; private set; } = true;

    public void UseFiftyFifty() { FiftyFiftyAvailable = false; }
    public void UseSkip() { SkipAvailable = false; }
    public void UseHint() { HintAvailable = false; }
}
