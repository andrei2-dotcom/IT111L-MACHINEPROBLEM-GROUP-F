using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace TriviaChallenge;

public class IdentificationQuestion : Question
{
    public IdentificationQuestion(string text, string category, Difficulty difficulty,
                                  string correctAnswer, string hint = null,
                                  IEnumerable<string> acceptedAnswers = null)
        : base(text, category, difficulty, correctAnswer, hint, acceptedAnswers)
    {
    }

    public override void DisplayQuestion(Control host, Action<string> onAnswerSelected)
    {
        ResetInput();

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            ColumnCount = 1,
            RowCount = 3,
            Height = 170,
            BackColor = Color.Transparent
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 34f));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 60f));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 64f));

        Label prompt = Theme.MakeLabel("Type your answer and press ENTER:", 11f, FontStyle.Regular, Theme.MutedText);
        prompt.Anchor = AnchorStyles.Left;

        TextBox box = Theme.MakeTextBox(false);
        box.Font = new Font("Segoe UI", 18f);
        box.Anchor = AnchorStyles.Left | AnchorStyles.Right;

        Button submit = Theme.MakeButton("SUBMIT", Theme.Primary, Theme.FontButton);
        submit.Anchor = AnchorStyles.None;
        submit.Size = new Size(240, 48);

        Action doSubmit = () =>
        {
            string typed = box.Text.Trim();
            if (typed.Length == 0) return;
            onAnswerSelected(typed);
        };

        submit.Click += (sender, e) => doSubmit();
        box.KeyDown += (sender, e) =>
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                doSubmit();
            }
        };
        box.HandleCreated += (sender, e) => box.BeginInvoke(new Action(() => box.Focus()));

        InputControls.Add(box);
        InputControls.Add(submit);

        layout.Controls.Add(prompt, 0, 0);
        layout.Controls.Add(box, 0, 1);
        layout.Controls.Add(submit, 0, 2);
        host.Controls.Add(layout);
    }

    public override bool CheckAnswer(string playerAnswer)
    {
        return MatchesAnyAnswer(playerAnswer);
    }

    protected override string BuildAutoHint()
    {
        return "The answer has " + CorrectAnswer.Length + " characters and starts with \""
               + CorrectAnswer[0] + "\".";
    }
}
