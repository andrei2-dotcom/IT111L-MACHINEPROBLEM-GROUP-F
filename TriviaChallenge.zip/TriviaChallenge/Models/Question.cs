using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace TriviaChallenge;

public abstract class Question
{
    private readonly List<string> _acceptedAnswers;

    protected readonly List<Control> InputControls = new List<Control>();

    protected Question(string text, string category, Difficulty difficulty,
                       string correctAnswer, string hint, IEnumerable<string> acceptedAnswers)
    {
        Text = text;
        Category = category;
        Difficulty = difficulty;
        CorrectAnswer = correctAnswer;
        Hint = hint ?? "";
        _acceptedAnswers = acceptedAnswers == null
            ? new List<string>()
            : acceptedAnswers.Where(a => !string.IsNullOrWhiteSpace(a)).ToList();
    }

    public string Text { get; }
    public string Category { get; }
    public Difficulty Difficulty { get; }
    public string CorrectAnswer { get; }
    public string Hint { get; }
    public IReadOnlyList<string> AcceptedAnswers { get { return _acceptedAnswers; } }

    public int Points { get { return DifficultyExtensions.BasePoints(Difficulty); } }

    public virtual int TimeLimitSeconds { get { return 0; } }
    public bool IsTimed { get { return TimeLimitSeconds > 0; } }

    public virtual int MaxPoints { get { return Points; } }

    public virtual bool SupportsFiftyFifty { get { return false; } }

    public abstract void DisplayQuestion(Control host, Action<string> onAnswerSelected);

    public abstract bool CheckAnswer(string playerAnswer);

    public virtual void ApplyFiftyFifty() { }

    public virtual void LockInput()
    {
        foreach (Control c in InputControls) c.Enabled = false;
    }

    public virtual int CalculateSpeedBonus(double secondsTaken) { return 0; }

    public virtual string FormatCorrectAnswer() { return CorrectAnswer; }

    public string GetHint()
    {
        return !string.IsNullOrWhiteSpace(Hint) ? Hint : BuildAutoHint();
    }

    protected virtual string BuildAutoHint()
    {
        return "No hint is available for this question.";
    }

    protected void ResetInput() { InputControls.Clear(); }

    public static string Normalize(string text)
    {
        if (text == null) return "";
        string[] parts = text.Trim().ToLowerInvariant()
            .Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
        return string.Join(" ", parts);
    }

    protected bool MatchesAnyAnswer(string playerAnswer)
    {
        string given = Normalize(playerAnswer);
        if (given.Length == 0) return false;
        if (given == Normalize(CorrectAnswer)) return true;
        return _acceptedAnswers.Any(a => Normalize(a) == given);
    }
}
